public class HoldInteger {
   protected int sharedInt;
 
   public HoldInteger() { super(); }

   public void setSharedInt( int val ) { sharedInt = val; }

   public int getSharedInt() { return sharedInt; }
}
