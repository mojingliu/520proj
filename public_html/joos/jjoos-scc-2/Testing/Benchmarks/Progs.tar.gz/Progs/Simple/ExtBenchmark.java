public class ExtBenchmark extends Benchmark {

  public ExtBenchmark() { 
    super(); 
  } 

  public void benchmark() 
  { // empty method
  }

}
