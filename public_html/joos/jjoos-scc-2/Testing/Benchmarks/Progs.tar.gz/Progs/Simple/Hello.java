import joos.lib.*;

public class Hello {

  public Hello() { super(); }

  public static void main(String argv[])
    { JoosIO f;
      f = new JoosIO();
      f.println("Hello World");
    }
} 
