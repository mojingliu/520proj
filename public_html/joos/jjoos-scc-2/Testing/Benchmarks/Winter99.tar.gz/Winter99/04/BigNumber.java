import joos.lib.*;

import Digit;

public class BigNumber 
{
protected Digit number;

    
public BigNumber(Digit value)
    {
        super();
        number = value;
    }

public Digit getDigit()
    {
        return number;
    }

public BigNumber reverse()
    {
        Digit local, temp, revlocal;
        
        local = number;
        revlocal = null;
        temp = null;
        
        while (local != null)
        {
            if (temp == null)
            {
                temp = new Digit(local.getVal());
                revlocal = temp;
            }
            else
            {
                temp = revlocal;
                revlocal = new Digit(local.getVal());
                revlocal.setNext(temp);
            }
            local = local.getNext();
        }
        
        return new BigNumber(revlocal);
    }
    
public int size()
    {
        int temp;
        Digit local;
        
        local = number;
        temp = 0;
        
        while (local != null)
        {
            temp++;
            local = local.getNext();
        }
        return temp;
    }

public boolean isZero()
    {
        return number.isZero();
    }
    
public boolean isEqual(BigNumber value)
    {
        Digit local, external;
        boolean result;

        result = true;
        
        if (value == null)
        {
            return false;
        }
        else
        {
            local = number;
            external = value.getDigit();
            
            while ((result != false) && !((local == null) && (external == null)))
            {
                if ((local == null) || (external == null))
                {
                    result = false;
                }
                else if (local.getVal() == external.getVal())
                {
                    local = local.getNext();
                    external = external.getNext();
                }
                else
                {
                    result = false;
                }
            }
            return result;
        }
    }

public boolean isBigger(BigNumber value)
    {
        if (value == null)
        {
            return true;
        }
        else if (this.isEqual(value))
        {
            return false;
        }
        else if (this.size() > value.size())
        {
            return true;
        }
        else if (this.size() < value.size())
        {
            return false;
        }
        else
        {
            Digit local, external;
            boolean result;

            result = true;
            local = this.reverse().getDigit();
            external = value.reverse().getDigit();

            while (!((local == null) && (external == null)))
            {
                if (local.getVal() == external.getVal())
                {
                    local = local.getNext();
                    external = external.getNext();
                }
                else
                {
                    if (local.getVal() > external.getVal())
                    {
                        result = true;
                    }
                    else
                    {
                        result = false;
                    }
                    local = null;
                    external = null;
                }
            }
            return result;
        }
    }
public boolean isSmaller(BigNumber value)
    {
        if (value == null)
        {
            return false;
        }
        else
        {
            return value.isBigger(this);
        }
    }

public BigNumber bigAdd(BigNumber value)
    {
        int carry, newdig;
        Digit result, temp, local, external;

        carry = 0;
        newdig = 0;
        result = null;
        temp = null;

        if (value == null)
        {
            result = number;
        }
        else
        {
            local = number;
            external = value.getDigit();

            while (!((local == null) && (external == null) && (carry == 0)))
            {
/* requires improvements... */

                if ((local == null) && (external == null))
                {
                    newdig = carry;
                }
                else if (local == null)
                {
                    newdig = external.getVal() + carry;
                    external = external.getNext();
                }
                else if (external == null)
                {
                    newdig = local.getVal() + carry;
                    local = local.getNext();
                }
                else
                {
                    newdig = local.getVal() + external.getVal() + carry;
                    local = local.getNext();
                    external = external.getNext();                    
                }
                
                carry = newdig/10;
                newdig = newdig%10;

                if (temp == null)
                {
                    temp = new Digit(newdig);
                    result = temp;
                }
                else
                {
                    temp.setNext(new Digit(newdig));
                    temp = temp.getNext();
                }
            }
        }
        
        return new BigNumber(result);
    }

public BigNumber mul(int value)
    {
        int carry, newdig;
        Digit result, temp, local;

        carry = 0;
        newdig = 0;
        result = null;
        temp = null;

        local = number;

        if (local.isZero())
        {
            result = new Digit(0);
        }
        else if (value == 0)
        {
            result = new Digit(0);
        }
        else if (value == 10)
        {
                /* Decalage... */
            temp = new Digit(0);
            temp.setNext(local);
            result = temp;
        }
        else
        {
            while (!((local == null) && (carry == 0)))
            {
/* requires improvements... */

                if (local != null)
                {
                    newdig = local.getVal()*value + carry;
                    local = local.getNext();
                }
                else
                {
                    newdig = carry;
                }
                
                carry = newdig/10;
                newdig = newdig%10;
                if (temp == null)
                {
                    temp = new Digit(newdig);
                    result = temp;                    
                }
                else
                {
                    temp.setNext(new Digit(newdig));
                    temp = temp.getNext();
                }
            }
        }
        
        return new BigNumber(result);
    }
    
public BigNumber bigMul(BigNumber value)
    {
        if (value == null)
        {
            return new BigNumber(new Digit(0));
        }
        else if (value.isZero() || number.isZero())
        {
            return new BigNumber(new Digit(0));
        }
        else
        {
            Digit external;
            BigNumber local, result;
            
            local = new BigNumber(number);
            external = value.getDigit();
            result = new BigNumber(new Digit(0));
            
            while (external != null)
            {
                result = (local.mul(external.getVal())).bigAdd(result);
                local = local.mul(10);
                external = external.getNext();
            }
            return result;
        }
    }
    
public String toString()
    {
        if (number == null)
        {
            return null;
        }
        else
        {
            return number.toString();
        }
    }
public void resetFromString(String arg)
    {
        Digit temp;
        int i,j, zero;
        
        if(arg == null)
        {
            number = new Digit(0);
            return;
        }
        i = arg.length();

        if(i >0)
        {
            j = (new Integer(arg.substring(i-1, i))).intValue();
            zero = (new Integer("0")).intValue();
            
            temp = new Digit(j - zero);
            number = temp;
            i = i-1;
            while(i > 0)
            {
                j = (new Integer(arg.substring(i-1, i))).intValue();
                temp.setNext(new Digit(j - zero));                
                temp = temp.getNext();
                i = i - 1;
            }
        }
        else
        {
            number = new Digit(0);
        }
        return;        
    }
    
            
public static void main(String[] args)
    {
        JoosIO f;
        BigNumber bigOne, bigTwo;
        String input1, input2, operator;
        
        bigOne = new BigNumber(null);
        bigTwo = new BigNumber(null);
        f = new JoosIO();

        f.println("Enter first big number :");
        input1 = f.readLine();
        f.println("Enter second big number :");
        input2 = f.readLine();
        bigOne.resetFromString(input1);
        bigTwo.resetFromString(input2);

        f.println("Enter the operator, please use one of the followings : =, <, >, +, *.");        
        operator = f.readLine();

        if (operator.equals("="))
        {
            f.println("Verifying equality : " + bigOne.isEqual(bigTwo));
        }
        else if (operator.equals(">"))
        {
            f.println("Verifying first one bigger then second : " + bigOne.isBigger(bigTwo));            
        }
        else if (operator.equals("<"))
        {
            f.println("Verifying first one is smaller then second : " + bigOne.isSmaller(bigTwo));
        }
        else if (operator.equals("+"))
        {
            f.println("Adding the two : " + bigOne.bigAdd(bigTwo));
        }
        else if (operator.equals("*"))
        {
            f.println("Multiplying the two : " + bigOne.bigMul(bigTwo));
        }
        else
        {
            f.println("The operator you specified is invalid,");
            f.println("please use one of the followings : =, <, >, +, *.");
        }
    }
}














