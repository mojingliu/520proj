public class Digit 
{
protected int val;
protected Digit next;

public Digit(int value)
    {
        super();
        val = value;
        next = null;
    }

public boolean isZero()
    {
        if ((val == 0) && (next == null))
        {
            return true;
        }
        else return false;
    }
    
public int getVal()
    {
        return val;
    }
public Digit getNext()
    {
        return next;
    }
public void setVal(int newval)
    {
        val = newval;
        return;
    }
public void setNext(Digit newdig)
    {
        next=newdig;
        return;
    }
public String toString()
    {
        if (next==null){
            return val + "";
        }
        else
        {
            return next.toString() + val;
        }
    }
    
}
