This archive contains the source code and compiled files for the JOOS
benchmark for group 04: Jourdain, Legare and Smith.

The command line used for compiling was 

"joosc BigNumber.java Digit.java" (compiled on skinner).

To run the program, type "java BigNumber".

The program asks for two inputs: positive decimal integers of
arbitrary length.  It then asks for an operator and performs the
corresponding operation. The available operators are:

= checks equality
< checks smaller than
> checks bigger than
+ adds the two numbers
* multiplies the two numbers.

Notes: The input typed at the prompt MUST be a string of digits and
nothing else. The program is in no way fault-tolerant: it will crash
if provoked.

The length of this program is considerably more than 100 lines, but
there's a lot of white space in there. We hope you won't hold it
against us.

