// Chef.java

// A Chef is a type of Person.
public class Chef extends Person
{
  // constructor 
  public Chef(String s)
  {
    super(s);
  }
  public String toString()
  {
    return "Chef named " + name;
  }
}
