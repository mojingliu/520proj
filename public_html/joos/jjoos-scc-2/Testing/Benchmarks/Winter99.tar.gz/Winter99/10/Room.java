// Room.java

import joos.lib.*;
import java.util.*;

// A Room is a container for Person objects.
public class Room
{
  // A collection of Person objects. 
  protected Vector people;
 
  // constructor
  public Room()
  {
    super();
    people = new Vector();
  }
  
  // Add a given Person object to this Room. 
  // (on the condition that it isn't already in the Room.) 
  public void addPerson(Person person)
  {
    if (!people.contains(person))
      {
	people.addElement(person);
      }
  }
  
  // Remove a given Person object from this Room. 
  public void removePerson(Person person)
  {
    int index;

    index = people.indexOf(person);
    if (index > -1)
      {
	people.removeElementAt(index);
      }
  }

  // Find the Person in this Room with the given name.
  // returns null if unsuccessful
  public Person findPerson(String name)
  {
    Person person;
    int index;
    
    index = 0;
    while(index < people.size())
      {
	person = (Person) people.elementAt(index);
	if (person.getName().equals(name)) return person;
	index++;
      }
    return null;
  }

  // prints the names of all the people in this Room
  public String toString()
  {
    Person person;
    String result;
    int index;

    index = 0;
    result = new String();
    
    while(index < people.size())
      {
	person = (Person) people.elementAt(index);
	result = result + person.toString() + "\n";
		
	index++;
      }

    return result;
  }
}
