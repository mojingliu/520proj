// Kitchen.java

import joos.lib.*;

// A Kitchen is a type of Room.
public class Kitchen extends Room
{
  // constructor  
  public Kitchen()
  {
    super();
  }
  
  public String toString()
  {
    return "Kitchen contains these people:\n" + super.toString();
  }
  
  // entry point 
  public static void main(String argv[])
  {
    String test;      // used to test the program
    Person person;      
    JoosIO output;
    Kitchen kitchen;
    Chef masterChef;    
    Person serf;
        
    kitchen = new Kitchen();
    masterChef = new Chef("Ludovic");
    serf = new Person("Sven");
    output = new JoosIO();

    //
    test = new String("Ludovic");
    //
    
    kitchen.addPerson(masterChef);
    output.println(kitchen.toString());

    kitchen.addPerson(serf);
    output.println(kitchen.toString());
    
    person = kitchen.findPerson(test);
    if (person == null)
      {
	output.println("Could not find '" + test + "'");
	output.println("Removing Sven.\n");
	kitchen.removePerson(serf);
      }
    else
      {
	output.println("Found " + person.toString());
	output.println("Removing " + person.toString() + "\n");
	kitchen.removePerson(person);
      }
    
    output.println(kitchen.toString());
  }
}



  
