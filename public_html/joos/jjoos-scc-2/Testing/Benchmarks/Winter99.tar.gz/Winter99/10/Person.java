// Person.java

public class Person
{
  // The name of the person.
  protected String name;

  // constructor
  public Person(String s)
  {
    super();
    name = s;
  }
  public String getName() 
  {
    return name;
  }
  public void setName(String s)
  {
    name = s;
  }
  public String toString()
  {
    return name;
  }
  
  // Is this Person object equivalent to the given object? 
  public boolean equals(Object obj)
  {
    Person person;
    person = (Person) obj;
    
    if (person.getName().equals(name)) return true;
    else return false;
  }
}
