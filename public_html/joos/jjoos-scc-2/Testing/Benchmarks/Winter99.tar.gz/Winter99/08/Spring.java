import joos.lib.*;
import java.util.*;

public class Spring
{
  protected int length;
  protected int flexibility;

public Spring(int a, int b)
{
  super();
  length = a;
  flexibility = b;
}

public int getLength()
{
  return length;
}

public int getFlexibility()
{
  return flexibility;
}

}
