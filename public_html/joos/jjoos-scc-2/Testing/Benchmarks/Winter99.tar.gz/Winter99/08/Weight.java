import joos.lib.*;
import java.util.*;

public class Weight
{

  protected int kilos;

  public Weight(int a)
  {
    super();
    kilos = a;
  }

public int getKilos()
{
  return kilos;
}

}
