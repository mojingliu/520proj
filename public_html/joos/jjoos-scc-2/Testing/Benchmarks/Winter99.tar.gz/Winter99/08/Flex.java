//ASSIGNMENT 1  CS3-8-520
//Group: #8
//Names: Javier SANCHEZ
//       Manuela-Ionelia DINI
//       Cosmin-Nicu DINI
//
//This applet evaluates and displays the efect of adding a weight on a 
//spring of known spring constant
//

import joos.lib.*;
import java.util.*;
import java.awt.*;
import java.applet.Applet;

public class Flex extends Applet
{

 protected Graphics g;
 protected int theWeight;
 protected int theFlexibility;
 protected int theLength;
 protected int newLength;

 protected Spring mySpring;
 protected Weight myWeight;

//-----------------------------------------------
public Flex()
{ 
super();
}
//----------------------------------------------
public void init()
  {
   theWeight = 100; //Kg
   theFlexibility = 7; // N/m
   theLength =100;    //initial length

   mySpring = new Spring(theLength, theFlexibility);

   myWeight=new Weight(theWeight);

//calculate new length according to formula
  newLength = mySpring.getLength() + 
(10*myWeight.getKilos())/mySpring.getFlexibility(); 

}
//-----------------------------------------------
public void paint(Graphics g)
{
  int circlePos;
  String weightComment; //label on botton of applet
  String springComment; //label on bottom of applet

  weightComment = myWeight.getKilos() + " Kg WEIGHT ON";

  springComment = "Spring constant: " + mySpring.getFlexibility() + " N/m";

  circlePos = 0;

//draw spring with no weight on
  while (circlePos < mySpring.getLength())
   {
     g.drawOval(25, circlePos, 50, 50);
     circlePos=circlePos + 10;
   }

  circlePos=0;
//draw spring with weight on
  while(circlePos < newLength)
   {
     g.drawOval(125, circlePos, 50, 50);
     circlePos=circlePos + 10;
   }

  circlePos=circlePos + 50;

//draw weight
  g.fillRoundRect(110, circlePos, 80, 40, 0, 0);
//draw weight attachment to spring
  g.drawLine(150, circlePos-40, 150, circlePos+30);

//write info about spring at bottom
  g.drawString("NO WEIGHT", 10, 380);
  g.drawString(weightComment, 110, 380);
  g.drawString(springComment, 110, 390);
}
//-------------------------------------------------
public void update (Graphics g)
{
  this.paint(g);
  return;
}
//--------------------------------------------------

public static void main (String [] args) {
  JoosIO f;
  f = new JoosIO();
  f.println("This is really an applet.  This is dummy output.");
}
}//end class Flex
