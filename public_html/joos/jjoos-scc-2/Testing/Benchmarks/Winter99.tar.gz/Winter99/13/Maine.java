import joos.lib.*;

public class Maine{

   public Maine(){ super();}
   
   public static void main(String[] args){
                
                
                int i;
		JoosIO out;
		JoosRandom randseq;
		IntArray table;
		BST bst;
		
		bst = new BST();
		
		out = new JoosIO();
		
		randseq = new JoosRandom(13);
		
		table = new IntArray(20);
		
		i = 0;
		
		// read numbers into the Vector
		
		while(i < 20){
		  table.set_next_Int(randseq.nextInt() % 100);
		  i++;
		}
		
		
		i = 0;
		
		//fill the BST
		
		while(i < 20){
		  bst.Add_Elt(table.get_ElementAt(i));
	          i++;
		}  
		
		out.println("The numbers are:");
		out.print(table + "\n"); // Vector traversal through toString()
		out.println("Sorted:");
		out.print(bst + "\n"); // inorder traversal through toString()
   
   }
   
 
   
}
