
// classic binary search tree

public class BST{

      
      protected TreeNode root;
      protected String s;
       
  
      public BST(){
       
            super();
            
            root = null;
            s = "";
            
      }
      
      
      
      public void Add_Elt(int key){
      
      
          TreeNode temp;
          TreeNode parent;
          int i;
          int side;
          side = 1;
          temp = parent = root;
          
          if(root == null){
             root = new TreeNode(key);
             return;
          }   
          
          
         
          while(temp!=null ){
                       
              if(key < temp.getValue()){
                   parent = temp;
                   temp = temp.get_Left();
                   side = -1;
              } 
              else{                   
                   parent = temp;
                   temp = temp.get_Right();
                   side = 1;
              }
                        
          }  // while
                
          if(side == 1)
              parent.set_Right(new TreeNode(key));
          else
              parent.set_Left(new TreeNode(key));  
       } 
      
      
   
      
     
      
      
      public void in_order(TreeNode node){
      
          if(node != null){
          
             this.in_order(node.get_Left());
             s = s + node.getValue() + " ";
             this.in_order(node.get_Right());
             
          }
          
      }             
      
      
      
      
      public String toString(){
         
         this.in_order(root);
         return s;
      }        
                     
                     
                       
      
      
      
              
 }   // class  
      
      
      
      
      
      
      
      
      
      
 
