
// class IntObject
// to circumvent incapacity to store ints in Vectors




public class IntObject{
	
	
    protected int valu;
    
 
    public IntObject(int value){
	 
	    super();
	    valu = value;
    }
 
	
	
    public int getValue(){

         return valu;
    }	 
 
 
}
