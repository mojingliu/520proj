// a node in the binary search tree


public class TreeNode{
 
     protected int key;                            
     protected TreeNode left, right;          // children
 
     
     public TreeNode(int value){
          
          super();
          key = value;
          left = right = null; 
     }
      
      
     public void set_Left(TreeNode Left){
     
          left = Left;
     }
     
     public TreeNode get_Left(){
     
          return left;
     }
          
     
     
     
     public TreeNode get_Right(){
     
          return right;
     }
     
     
     public void set_Right(TreeNode Right){
     
          right = Right;
     }
       
     public int getValue(){
     
          return key;
     }
     
     
     
}//TreeNode	   	      
 
