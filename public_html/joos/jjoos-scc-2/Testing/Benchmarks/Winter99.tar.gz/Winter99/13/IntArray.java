/* IntArray.java

                   
                    class IntArray.java

    		        Philippe Laporte

                   Universite McGill

                    January 29 1997

I think the following shows good circumventing of the problem of using ints in Vectors */



import joos.lib.*;

import java.util.*;

public class IntArray{


  
   protected Vector table;                 
   protected int num_elts; 
   protected int table_size;
   
   public IntArray(int size){
   
      super();
      table = new Vector(size);
      table.setSize(size);
      table_size = size;
      num_elts = 0;
   }    
    
   
   public String toString(){
  
       String s;
       int i;
       i = 0;
       s = "";
       
       while(i < num_elts){
       
          s = s + (((IntObject)table.elementAt(i)).getValue());
          s = s + " ";
          i++;
       }
       
       if(s == null)
         return " ";
       else           
         return s;
       
   }        
       
       
       
            
       
       
      
 
       
   public int set_next_Int(int key){

       if(num_elts < table_size){
         table.insertElementAt(new IntObject(key),num_elts);
         num_elts++;
         return num_elts;
       }
       else return -1;     
   }

       
   public int get_num_elts(){
       return num_elts;
   }

 
   public int get_ElementAt(int key){
   
       if(key < table_size)
        return ((IntObject)table.elementAt(key)).getValue();
       else
        return 100;
   }


} // intArray       	 		
