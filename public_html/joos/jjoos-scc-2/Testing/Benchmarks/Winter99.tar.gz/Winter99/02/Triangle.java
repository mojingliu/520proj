////////////////////////////////////////////////////////////////////////////////
//
//  Triangle.java
//
//  Coded by:
//	Andrew Hryckowian, Francois Kosie, Peter P Toth
//
////////////////////////////////////////////////////////////////////////////////


import joos.lib.*;
import java.awt.*;
import Vertex;
import buff.*;
import ScanBuffer;

////////////////////////////////////////////////////////////////////////////////////////////////////////
//CLASS
//
// The Triangle class exists to store and display triangles.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////
public class Triangle {

	//**** the Triangle vertices ****
	protected Vertex p0, p1, p2;
	protected int FPP;	//Fixed Point Precision "constant"
	
	public Triangle(Vertex p0in, Vertex p1in, Vertex p2in) {
		super();
				
		Vertex temp;

		FPP= 10000;
		p0 = p0in;
		p1 = p1in;
		p2 = p2in;
		
	        // This sorts the vertices such that their y value
        	// is nondecreasing as the index of the vertex increases,
      		// by swapping them as it goes along.
		if (p2.y() < p1.y()) {
			temp = p1;
			p1 = p2;
			p2 = temp;
		}
		if (p2.y() < p0.y()) {
			temp = p0;
			p0 = p2;
			p2 = temp;
		}
		if (p1.y() < p0.y()) {
			temp = p0;
			p0 = p1;
			p1 = temp;
		}
	}        

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// public displayFill(BuffImg b, int sWidth, int sHeight)
//
// This routine fills the Triangle with the designated color.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////

public void displayFill(BuffImg b, int sWidth, int sHeight) {
        ScanBuffer sBuffer1;
        ScanBuffer sBuffer2;

        sBuffer1 = new ScanBuffer(sWidth, sHeight);
        sBuffer2 = new ScanBuffer(sWidth, sHeight);
	
        // Triangle points are now sorted in the constructor for the triangle
	
	//**** Checks type of triangle through cross product operation ****

        if (this.vectZ(p0.x() - p1.x(), p0.y() - p1.y(),
	               p2.x() - p1.x(), p2.y() - p1.y()))
	{
                //**** p1 ON LEFT, that is: middle y-valued point on LEFT ****
		
                // first draw edges in ScanBuff
                this.lineBres(sBuffer1, p0, p1);
                this.lineBres(sBuffer2, p0, p2);

                // Then scan out buffers to screen
                this.scan(p0.y(), p1.y(), sBuffer1, sBuffer2, b);

                // Draw remainder of triangle
                if (p2.y() > p1.y()) {
                        this.lineBres(sBuffer1, p1, p2);
                        this.scan(p1.y(), p2.y(), sBuffer1, sBuffer2, b);
                }
        } else {

            //**** p1 ON RIGHT ****

                this.lineBres(sBuffer1, p0, p2);
                this.lineBres(sBuffer2, p0, p1);
                this.scan(p0.y(), p1.y(), sBuffer1, sBuffer2, b);

                if (p2.y() > p1.y()) {
                        this.lineBres(sBuffer2, p1, p2);
                        this.scan(p1.y(), p2.y(), sBuffer1, sBuffer2, b);
                }
        }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// public void lineBres(ScanBuffer sb, Vertex v1, Vertex v2)
//
//  This public method implements Bresenham line drawing into a ScanBuffer.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////

public void lineBres(ScanBuffer sb, Vertex v1, Vertex v2) {

        int i, delta;
        int halfDelta;
        int deltaX, deltaY;
        int errNumX, errNumY;
        int incrX, incrY;
        int dyRed, dyGreen, dyBlue;
        int R, G, B;
//	int R2, G2, B2;
        int x1, y1;
	int yDiff;

	R= FPP * v1.R();
	G= FPP * v1.G();
	B= FPP * v1.B();
	if ((yDiff = v2.y() - v1.y()) != 0) {
		dyRed   = (FPP * (v2.R() - v1.R())) / yDiff;
		dyGreen = (FPP * (v2.G() - v1.G())) / yDiff;
		dyBlue  = (FPP * (v2.B() - v1.B())) / yDiff;
	} else {
		dyRed= 0;
		dyGreen= 0;
		dyBlue= 0;
	}

	x1 = v1.x();
	y1 = v1.y();
	
	errNumX = 0;
	errNumY = 0;

	//**** calculate change in x ****
        if ((deltaX = v2.x() - v1.x()) > 0) {
                incrX = 1;
        } else if (deltaX < 0) {
                deltaX = -deltaX;
                incrX = -1;
        } else {
                incrX = 0;
        }

	//**** calculate change in y ****
        if ((deltaY = v2.y()-v1.y()) > 0) {
                incrY = 1;
        } else if (deltaY < 0) {
                deltaY = -deltaY;
                incrY = -1;
        } else {
                incrY = 0;
        }

	//**** find dominant direction ****
//	JOOS does not support "?:"
//      delta = deltaX > deltaY ? deltaX : deltaY;
	if (deltaX > deltaY) {
		delta = deltaX;
	} else {
		delta = deltaY;
	}

//      halfDelta = delta >> 1; // divide by 2
	halfDelta = delta / 2;

        i = 0;
        while (i <= delta) {

		//**** need to putpixel(x1, y1, Col)  ****
		//**** in this case we set the value  ****
		//**** in the given ScanBuffer object ****

                sb.setXValue(x1, y1, new Color(R/FPP, G/FPP, B/FPP));
		
                errNumX = errNumX + deltaX;

		//**** increment error accumulators ****
		//**** change x or y if necessary   ****
                if (errNumX > halfDelta) {
                        errNumX = errNumX - delta;
                        x1 = x1 + incrX;
                }
                errNumY = errNumY + deltaY;
                if (errNumY > halfDelta) {
                        errNumY = errNumY - delta;
                        y1 = y1 + incrY;
                        R= R + dyRed;
                        G= G + dyGreen;
                        B= B + dyBlue;                     
                }
                i = i + 1;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// public void scan(int y1, int y2, ScanBuffer sb1, ScanBuffer sb2, BuffImg b)
//
//  This public method scans out the contents of two ScanBuffer x limits to the screen
//  by going down the y-direction.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////

public void scan(int y1, int y2, ScanBuffer sb1, ScanBuffer sb2, BuffImg b) {
        int x, y;
        int xEnd;
        int dxRed, dxGreen, dxBlue;
        int R, G, B;
        Color col1, col2;
	int xDiff;
                
        y = y1;
	while (y <= y2) {
		x = sb1.getXValue(y);
		xEnd = sb2.getXValue(y);
		
		col1 = sb1.getColValue(y);
		col2 = sb2.getColValue(y);
			
		R = FPP * col1.getRed();
		G = FPP * col1.getGreen();
		B = FPP * col1.getBlue(); 
			
		if ((xDiff = xEnd - x) != 0) {
			dxRed   = (FPP * col2.getRed()   - R)/ xDiff;
			dxGreen = (FPP * col2.getGreen() - G)/ xDiff;
			dxBlue  = (FPP * col2.getBlue()  - B)/ xDiff;
		} else {
			dxRed= 0;
			dxGreen= 0;
			dxBlue= 0;
		}
		while (x < xEnd) {
                        b.setPixel(x, y, new Color(R/FPP, G/FPP, B/FPP));
			x = x + 1;
			R = R + dxRed;
			G = G + dxGreen;
			B = B + dxBlue;
		}
		y = y + 1;
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// public boolean vectZ(int x, int y, int x2, int y2)
//
//  This public method returns the z direction sign of the crossproduct of two vectors.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////

public boolean vectZ(int x, int y, int x2, int y2) {
        return (x*y2 >= y*x2);
}

} // End of class Triangle
