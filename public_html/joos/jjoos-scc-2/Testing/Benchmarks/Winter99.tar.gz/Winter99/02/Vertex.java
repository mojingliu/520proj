////////////////////////////////////////////////////////////////////////////////
//
//  Vertex.java
//
//  Coded by:
//	Andrew Hryckowian, Francois Kosie, Peter P Toth
//
////////////////////////////////////////////////////////////////////////////////



import joos.lib.*;

////////////////////////////////////////////////////////////////////////////////////////////////////////
//CLASS
//
// Vertex: A simple class, contains x,y values for vertices in the plane.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////
public class Vertex {
	protected int xVal, yVal;
	protected int Rb, Gb, Bb;

	public Vertex(int x1, int y1) {
		super();
		xVal= x1;
		yVal= y1;
		Rb= 255;
		Gb= 255;
		Bb= 255;
	}
	
	public Vertex(int x1, int y1, int R1, int G1, int B1) {
		super();
		xVal= x1;
		yVal= y1;
		Rb= R1;
		Gb= G1;
		Bb= B1;
	}

	public int R() {
		return(Rb);
	}
	
	public int G() {
		return(Gb);
	}
	
	public int B() {
		return(Bb);
	}	
	
	public int x() {
		return xVal;
	}

	public int y() {
		return yVal;
	}
}
