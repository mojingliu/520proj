////////////////////////////////////////////////////////////////////////////////
//
//  ScanBuffer.java
//
//  Coded by:
//	Andrew Hryckowian, Francois Kosie, Peter P Toth
//
////////////////////////////////////////////////////////////////////////////////


import joos.lib.*;
import java.util.*;
import java.awt.*;

////////////////////////////////////////////////////////////////////////////////////////////////////////
//CLASS
//
// ScanBuffer is a class used in drawing triangle edges; basically it is an array of x-values
// indexed by y-values; straightforward.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////


public class ScanBuffer {
	protected Vector b, c;
	protected int sX, sY;

        public ScanBuffer(int sX1, int sY1) {
                super();

                int i;

		sX = sX1;
		sY = sY1;
		b = new Vector(sY);
		c = new Vector(sY);
		// size of b should be sY
                i = 0;
		while (i < sY) {
			b.addElement(new Integer(0));
			c.addElement(new Color(0));
			i = i + 1;
		}
	}

	public int getXValue(int y1) {
		if ((y1 >= 0) && (y1 < sY)) {
                        return(((Integer)(b.elementAt(y1))).intValue());
		} else {
			return(0);
		}
	}
	
	public Color getColValue(int y1) {
		if ((y1 >= 0) && (y1 < sY)) {
                        return((Color)(c.elementAt(y1)));
		} else {
			return(new Color(0, 0, 0));
		}
	}	
	

	public void setXValue(int x1, int y1, Color col) {
		if ((y1 >= 0) && (y1 < sY)) {
			b.setElementAt(new Integer(x1), y1);
			c.setElementAt(new Color(col.getRed(), col.getGreen(), col.getBlue()), y1);
		}
	}
}
