////////////////////////////////////////////////////////////////////////////////
//
//  TriDraw.java
//
//  Coded by:
//	Andrew Hryckowian, Francois Kosie, Peter P Toth
//
////////////////////////////////////////////////////////////////////////////////


import joos.lib.*;
import java.awt.*;
import java.util.*;
import Triangle;
import buff.*;

public class TriDraw extends Frame
{
        protected Image resultImg;
        protected Dimension winSize;
	protected Random rObj;

        public TriDraw(Dimension winSizeParam) {
                super();
	
                winSize = winSizeParam;
                this.resize(440, 440);
                  // In order to allow for the top and edges, add 40
		rObj = new Random();
        }

	public Image getResultImg() {
		return resultImg;
	}

	public void setResultImg(Image i) {
		resultImg = i;
	}

	public Dimension getWinSize() {
		return winSize;
	}

	public void setWinSize(Dimension d) {
		winSize = d;
	}

        public static void main(String args[]) {
                BuffImg myimg;
                TriDraw window;
		JoosIO f;
		Triangle t;
		int i, x, y, z, col, maxtri; 
                boolean notbatch;

		f = new JoosIO();

                f.println("Gouraud Shaded Interpolated Triangle Filler");
                f.println("By Francois Kosie, Andrew Hryckowian, and Peter P Toth");
                f.println("January 29, 1999.\n");
                f.print("Run in batch mode (y/n): ");
                notbatch = f.readLine().equals("n");
                window = new TriDraw(new Dimension(400, 400));
                window.setTitle("Gouraud Shaded Interpolated Triangle Filler");
		if (notbatch)  window.show();
                myimg = new BuffImg(window.getWinSize());
                myimg.clear();

        // Call the triangle drawer, passing it "myimg" as the BuffImg
	// Randomly creates 10 triangles of various colour and vertex
	// position

		f.println("");
		f.print("Enter the number of triangles to display: "); 
		
      		maxtri = f.readInt();
		
		i=0;
		while (i < maxtri) {
			t = new Triangle(
				new Vertex(window.r(400),
					   window.r(400),
					   window.r(255),
					   window.r(255),
					   window.r(255)),
				new Vertex(window.r(400),
					   window.r(400),
					   window.r(255),
					   window.r(255),
					   window.r(255)),
				new Vertex(window.r(400),
					   window.r(400),
					   window.r(255),
					   window.r(255),
					   window.r(255)));
			t.displayFill(myimg, 400, 400);
			i = i + 1;
		}
		// Create the image object from the BuffImg
                if (notbatch) {
                   window.setResultImg(myimg.makeImg(window));
		   // Draw the final image
                   window.repaint();
                }
		f.println("Done generating the images");
                if (notbatch) {
                   f.readLine();
		   window.dispose();
                }
        }

        public void paint(Graphics g) {
                if (resultImg != null) {
                        g.drawImage(resultImg, 10, 30, this);
                }
        }

	//
	// Generates a random (positive) number from 0 to n-1
	//
	public int r(int n) {
		int i;

		i = rObj.nextInt() % n;
		// Take the absolute value of the number
		if (i < 0) {
			return -i;
		} else {
			return i;
		}	
	}
}

