////////////////////////////////////////////////////////////////////////////////
//
//  BuffImg.java
//
//  Coded by:
//	Andrew Hryckowian, Francois Kosie, Peter P Toth
//
////////////////////////////////////////////////////////////////////////////////


//  NOTE: This will be an external Java file, not a Joos file.
package buff;

import java.awt.*;
import java.awt.image.*;

public class BuffImg
{
        int [] imgAr;
        int width, height, size;

        public BuffImg(Dimension d) {
                this.width = d.width;
                this.height = d.height;
                size = d.width * d.height;
                imgAr = new int[size];
                clear();
        }

        public void clear() {
                int i;
                for (i = 0; i < size; i++) {
                        imgAr[i] = 0; // alpha = 0 too.
                }
        }

        public void setPixel(int x, int y, Color col) {
                imgAr[x + (y * height)] = col.getRGB();
        }

        public Image makeImg(Component cpt) {
                MemoryImageSource source;
                Image img;
                source = new MemoryImageSource(width, height, imgAr, 0, width);
                img = cpt.createImage(source);
                return img;
        }
}
