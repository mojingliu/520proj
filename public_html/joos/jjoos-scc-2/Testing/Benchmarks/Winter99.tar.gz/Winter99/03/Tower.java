/*
 * JOOS Benchmark
 * 308-502 Compiler Design, Winter 1999
 * McGill University
 *
 * Christelle Ravard
 * Jerome Barreau
 * group 03
 */

/*
  This file computes the Tower class. A Tower is a stack of discs of several 
  sizes. It is represented as a vector of intergers (the interger is the size 
  of the disc).
  We have implemented the following methods :
  - addElement :  allows us to add an element at the top of the current Tower 
    (the parameter "newval" is the size of the disc to add)
  - removeElement : allows us to remove the upper element of the Tower
  - getElement : allows us to get the size of the upper element of the Tower
  - isEmpty : it is a test to know if a Tower is empty or not (it returns a 
    boolean)
  - toString : allows us to draw the Tower on the screen
*/

import joos.lib.*;
import java.util.*;


public class Tower
{

  // protected field
  protected Vector Val;


  public Tower()
  {
  
    super();
    Val=new Vector();
  
  }

  // addElement :  adds an element at the top of a Tower
  public boolean addElement(Integer newval)
  {
    
    Val.addElement(newval);
    
    return true;
  
  }

  // removeElement : removes the upper element of a Tower
  public boolean removeElement()
  {
  
    boolean ret;
    
    if (Val.size()!=0) {
      Val.removeElementAt(Val.size()-1);
      ret=true;
    }
    else {
      ret=false;
    }

    return ret;
  
  }

  // getElement : gets the size of the upper element of a  Tower
  public Integer getElement()
  {
  
    Integer ret;
  
    if (Val.size()!=0) {
      ret=(Integer)(Val.elementAt(Val.size()-1));
    }
    else {
      ret=new Integer(0);
    }
    
    return ret;
  
  }

  // isEmpty :  tests if a Tower is empty or not (it returns a boolean)
  public boolean isEmpty()
  {
  
    return (Val.size()==0);
    
  }

  // toString : draws the Tower on the screen
  public String toString()
  {
  
    String twr;
    int i, j, max, skip, sz;
    
    twr=new String();
    if (Val.size()!=0) {
      max=((Integer)(Val.elementAt(0))).intValue();
      for(i=1;i<Val.size();i++) {
        if (((Integer)(Val.elementAt(i))).intValue()>max) {
          max=((Integer)(Val.elementAt(i))).intValue();
        }
      }
      
      i=Val.size()-1;
      while (i>=0) {
        sz=((Integer)(Val.elementAt(i))).intValue();
        skip=max-sz;
        for(j=0;j<skip;j++) {
         twr=twr+" ";
        }
        for(j=0;j<2*sz;j++) {
          twr=twr+"-";
        }
        twr=twr+"\n";
        i=i-1;
      }
      for(j=0;j<2*max;j++) {
        twr=twr+"=";
      }
    }
    else {
      twr="\n==========";
    }
    	
  
  
    return twr;
  
  }



}	// end of Tower class
