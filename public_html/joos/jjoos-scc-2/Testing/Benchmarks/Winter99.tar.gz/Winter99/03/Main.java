/*
 * JOOS Benchmark
 * 308-502 Compiler Design, Winter 1999
 * McGill University
 *
 * Christelle Ravard
 * Jerome Barreau
 * group 03
 */

/*
 This file computes the Main of our program.
*/




import joos.lib.*;


public class Main
{

  public Main()
  {
  
    super();
  
  }


  public static void main(String argv[])
  {
  
    JoosIO system;
    Hanoi T1, T2, T3;
    CList save;
    int choice, from, to;
    boolean ok;
    Integer elem;
    
    system=new JoosIO();
    T1=new Hanoi();
    T2=new Hanoi();
    T3=new Hanoi();
    elem=new Integer(0);
    
    // init
    T1.addElement(new Integer(5));
    T1.addElement(new Integer(4));
    T1.addElement(new Integer(3));
    T1.addElement(new Integer(2));
    T1.addElement(new Integer(1));
    save=null;
    
    // main loop
    
    choice=0;
    while (choice!=9) {
      system.println("\nTower #1\n\n" + T1 + "\n");
      system.println("Tower #2\n\n" + T2 + "\n");
      system.println("Tower #3\n\n" + T3 + "\n");
      
      system.println("\nMenu :\n1. Move\n9. Quit");
      choice=system.readInt();
      if (choice==1) {
        system.print("from : ");
        from=system.readInt();
        system.print("to   : ");
        to=system.readInt();
        if (from<1 || from>3 || to<1 || to>3) {
          system.println("bad numbers... Try again !\n");
        }
        else {
          ok=false;
          if (from==1 && !T1.isEmpty()) {
            elem=T1.getElement();
            T1.removeElement();
            ok=true;
          }
          else if (from==2 && !T2.isEmpty()) {
            elem=T2.getElement();
            T2.removeElement();
            ok=true;
          }
          else if (from==3 && !T3.isEmpty()) {
            elem=T3.getElement();
            T3.removeElement();
            ok=true;
          }
          if (ok) {
            if (to==1) {
              ok=T1.addElement(elem);              
            }
            else if (to==2) {
              ok=T2.addElement(elem);
            }
            else if (to==3) {
              ok=T3.addElement(elem);
            }
            
            if (!ok) {
              system.println("Can't do that !");
              if (from==1) {
                T1.addElement(elem);
              }
              else if (from==2) {
                T2.addElement(elem);
              }
              else if (from==3) {
                T3.addElement(elem);
              }
            }
            else {
              save=new CList(save);
              save.setValue(new Integer(from), new Integer(to));
            }
          }
          else {
            system.println("The tower #" + from + " is empty.\n");
          }
        }
      
      }
      if (T1.isEmpty() && T2.isEmpty()) {
        choice=9;
        system.println("\n" + T3 + "\n");
        system.println("\nYOU W I N !\n");
        system.println("you did it in " + save.length() + " moves :");
        system.println("\n" + save);
        system.println("\nThanks for playing this little game...");      
     }
    }


  
  }	// end of main



}	// end of Main class
