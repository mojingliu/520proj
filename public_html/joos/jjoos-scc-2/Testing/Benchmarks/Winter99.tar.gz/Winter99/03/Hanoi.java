/*
 * JOOS Benchmark
 * 308-502 Compiler Design, Winter 1999
 * McGill University
 *
 * Christelle Ravard
 * Jerome Barreau
 * group 03
 */

/*
 This file computes the Hanoi class which itself extends the Tower class.
 The difference between Hanoi towers and general ones is that Hanoi towers are 
 orderly that is to say that their elements must always be stored the smaller 
 above the bigger. 
*/


import joos.lib.*;


public class Hanoi extends Tower
{

  public Hanoi()
  {
  	
    super();
    
  }

  // this method is a restriction to the former "addElement" method developped
  // in the Tower class. 
  public boolean addElement(Integer newval)
  {
    boolean ret;
    
    ret=false;
    if (newval.intValue()<=(this.getElement()).intValue() || this.isEmpty()) {
      super.addElement(newval);
      ret=true;
    }
    return ret;
  
  }



}	// end of Hanoi class
