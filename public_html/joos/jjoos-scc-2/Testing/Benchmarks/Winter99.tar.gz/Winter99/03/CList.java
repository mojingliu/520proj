/*
 * JOOS Benchmark
 * 308-502 Compiler Design, Winter 1999
 * McGill University
 *
 * Christelle Ravard
 * Jerome Barreau
 * group 03
 */


/*
  This file computes the CList class. This is a "chained list" which purpose 
  is to store the different moves the player made. It is a structure of two
  integers (the first one "form" is the number of the Tower from which an
  element is removed, the second one "to" is the number of the Tower to which
  the element is added) and the previous element of the CList (i.e. the
  previous move).

  We have implemented the following methods :
  - setValue : set the values of the variables "from" and "to".
  - length : recursive function - returns the length of the list.
  - toString : returns (on the screen) all the moves of the player.
*/


import joos.lib.*;

public class CList
{

  // protected field


  protected Integer clfrom;
  protected Integer clto;
  protected CList Next;


  public CList(CList nxt)
  {
  
    super();
    Next=nxt;
  
  }

  // setValue : set the values of the variables "from" and "to"
  public void setValue(Integer frm, Integer t)
  {
  
    clfrom=frm;
    clto=t;
  
  }

  // length : recursive function - returns the length of the list.
  public int length()
  {
  
    int ret;
  
    if (Next==null) {
      ret=1;
    }
    else {
      ret=1+Next.length();
    }
  
    return ret;
  
  }


  // toString : returns (on the screen) all the moves of the player.
  public String toString()
  {
  
    String ret;
        
    if (Next==null) {
      ret="" + clfrom + "-" + clto + ";";
    }
    else {
      ret=Next.toString() + clfrom + "-" + clto + ";";
    }
    
    return ret;
      
  }

}	// end of CList class
