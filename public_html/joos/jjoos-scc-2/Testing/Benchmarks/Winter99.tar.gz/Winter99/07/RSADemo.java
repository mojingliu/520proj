/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- */


import joos.lib.*;

/*
 * RSADemo a is simple class that implements a toy demo of the ubiquious RSA encryption algorithm.
 * As it stands, it provides no user interaction: it simply encrypts a string embedded in this class, 
 * prints out the ciphertext, and then procedes to decrypt the produced ciphertext to recover the original
 * string.  The public and secret keys used for the RSA algorithm in this class are instance of the 
 * RSAKeyPair class which encapsulates the details of the creation of the keys. 
 */
	

public class RSADemo
{ 

  /* 
   * Valid RSA public/secret key pair.
   */

protected RSAKeyPair mRSAKey;


	
  /* 
   * Constructor. Initializes class with a RSA public/secret key pair.
   */

public RSADemo() 
    {
      super();
      mRSAKey = new RSAKeyPair();

    }

    
public static void main(String argv[]) 
    {
      RSADemo RSADemoInstance;

      RSADemoInstance  = new RSADemo(); 
      RSADemoInstance.demo("The Bengal is a relatively new breed, descended from a cross between wild Asian Leopard Cats" +
"and domestic shorthairs. It is a large spotted cat with a short, glossy coat." +
"Well-bred Bengals are active, intelligent companions, but buyers are advised to use caution since" +
"those within 3 generations of the wild outcross may still exhibit the wild" +
"temperament of their wild ancestors. Bengals are not accepted in all associations. ");
      	
    }



  /*
   * Core of the RSA algorithm where the public key of a user is used to encrypt a message (integer),
   * using modular arithmetic. 
   */

public int encrypt(int aCharacter)
    {
      int e, n;
      e = mRSAKey.getPublicKey().getFirst();
      n = mRSAKey.getPublicKey().getSecond();
	
      return this.modularExp(aCharacter , e, n);
    }


  /*
   * Core of the RSA algorithm were the secret key of a user  is used to decrypt a message (integer),
   * using modular arithmetic.
   */

public int decrypt(int aCode) {
	
	int d,n;
	d = mRSAKey.getSecretKey().getFirst();
	n = mRSAKey.getSecretKey().getSecond();
	
	return this.modularExp(aCode , d, n);
}
    



  /*
   * Recursive modular exponention function.
   */
     
public int modularExp(int aNumber, int aExponent, int aModulus)
    {
      int temp;
	
      if(aExponent ==0)
        return 1;
      else if( (aExponent%2) == 1)  
        return (this.modularExp(aNumber, aExponent -1, aModulus)* aNumber) % aModulus; 
      else {
        temp = this.modularExp(aNumber, aExponent/2, aModulus);
        return (temp * temp) % aModulus;
      }
	    
    }
    	

  /*
   * Encryption/decryption engine. Encrypts a argument string in a simple fashion by applying the RSA algorithm to
   * successively to the numeric value of each caracter found in the string; the computed encrypted values are them 
   * printed as the ciphertext (as integers), and each caracters is them decrypted to recover the original string.
   * Some hacks were needed in this method in order to convert strings to chars to integers and back again 
   * within the limitations of Joos.
   *
   */


public void demo(String aString) {

  int i;
  int value;
    
  char t;
  Character c;
  JoosIO io;
  StringBuffer buffer, encryptedMessage;
  String str;

  str = new String();
  buffer = new StringBuffer();
  io = new JoosIO();
    
  i = 0;


  io.println("Original String:" + aString );
  io.println("");
  io.println("Encrypted String: ");
  while(i < aString.length()) {
    c = new Character(aString.charAt(i));
    t = c.charValue();   

    value =  t;
    value = this.encrypt(value);
    io.print("" + value +" ");

     
    value = this.decrypt(value);
      
      
    t = (char) value;
    c = new Character(t);

    buffer.append(c.toString());
    ;
    i++;
  }

  io.println("");
  io.println("");
  io.println("Recovered String:" + buffer);
  return;
}

}
    
    

   
       

 
 
 
 

 




  











