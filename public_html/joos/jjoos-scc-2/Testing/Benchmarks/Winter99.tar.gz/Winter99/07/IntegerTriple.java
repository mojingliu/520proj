/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- */

import joos.lib.*;

	
/* 
 * Class that serves as a data structure to hold 3 integers
 */

public class IntegerTriple 
{
    protected int mFirst,mSecond, mThird;

	public IntegerTriple(int a, int b, int c) {
	    super();
	    mFirst = a;
	    mSecond = b;
	    mThird = c;
	}	

	
    public int getFirst() {
	return mFirst;
    }
    public int getSecond() {
	return mSecond;
    }
    public int getThird() {
	return mThird;
    }

    public void setFirst(int aNumber){
	mFirst = aNumber;
    }

    public void setSecond(int aNumber){
	mSecond = aNumber;
    }

    public void setThird(int aNumber){
	mThird = aNumber;
    }

    public String toString(){
	return "" + mFirst + " " + mSecond + " " +  mThird;
    }
	
	
}
 



 





