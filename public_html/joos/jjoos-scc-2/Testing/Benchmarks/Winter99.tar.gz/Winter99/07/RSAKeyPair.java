/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- */


/*
 * Class whoses instances represent RSA public/secret key pairs. As it stands all generated key 
 * pairs will be identical due to the use of 'magic numbers'. To counter this problem the use of
 * randomly generated primes would be needed.
 *
 */



public class RSAKeyPair 
{
  

  protected IntegerTriple  mPublicKey, mSecretKey;
    
  /*
   * Constructor. Generates an RSA public/secret key pair, as specified by the description of the RSA algorithm.
   * Makes use of hardcoded primes and another 'magic' number
   */

  public RSAKeyPair() {
    super();
    int primeA, primeB, n, e, d,phi;
    IntegerTriple tri;
       
    primeA = 17;
    primeB = 29;
    n = primeA * primeB;
    phi = (primeA -1) * (primeB -1);

    /* 13 is relatively prime to phi */
    e = 13;
	
  /* Compute the multiplicative inverse of e mod phi. It is uniquely defined.  The inverse will be stored  
   * in the second integer of the integer triple instance  
   */ 
    tri = new IntegerTriple(e, phi,0);
    tri = this.euclid(tri);

    mPublicKey = new IntegerTriple(e,n,0);
    mSecretKey = new IntegerTriple(tri.getSecond(), n, 0);
    
  }




  /*
   * Recursive function to compute the gcd <i>d</i> of two integers <i> (x, y)</i>, as well as the coefficients 
   * of the gcd expressed as a linear combination of x and y. (i.e d = ax + by)
   */
  public IntegerTriple euclid(IntegerTriple aInput) 
    {
      int a ,b, temp;
      int x, y;
      IntegerTriple res;
	
      a = aInput.getFirst();
      b = aInput.getSecond();

      if(b == 0) {
        res = new IntegerTriple(a,1,0);
      } 
      else {
        aInput.setFirst(b);
        aInput.setSecond(a % b);
        res = this.euclid(aInput);
	    
        x = res.getSecond();
        y = res.getThird();

        res.setSecond(y);
        res.setThird(x - (a/b)* y);
      }
      return res;
    }
	

  public IntegerTriple getPublicKey() {
    return mPublicKey;
  }
    
  public IntegerTriple getSecretKey() {
    return mSecretKey;
  }
   
  public String toString(){
    return "Public Key: (" + mPublicKey + ")  Secret Key: (" + mSecretKey + ")";
  }
	
    
}

   



































