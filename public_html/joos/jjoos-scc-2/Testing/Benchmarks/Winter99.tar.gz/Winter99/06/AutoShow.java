import joos.lib.*;
import java.util.*;

public class AutoShow
{
  protected Vector Contestants;
  protected int NumContestants;
  
  // initialize NumContestants
  public AutoShow (int numC)
  {
    super();
    Contestants = new Vector(numC);
    NumContestants = 0;
  }

  // adds a contestant to the Contestants Vector
  public void addContestant(LandTransportation C)
  {
    Contestants.addElement(C);
    NumContestants++;
  }

  // judge the auto show based on how long it would take to travel d miles
  // and how many vehicles one would need to carry n people there
  public LandTransportation judgeContest(int d, int n, int r)
  {
    LandTransportation Leader;
    int i;
    JoosIO f;

    f = new JoosIO();

    if (NumContestants < 1) {
	f.println("No contestants in auto show -- no winner!\n");
	return(null);
    }

    Leader = (LandTransportation) Contestants.elementAt(0);
    for (i = 0; i < NumContestants; i++)
    {	
	// whichever car takes the least amount of time and gas to transport n
	// passengers d miles will win.
	if (this.evalC((LandTransportation) Contestants.elementAt(i), d, n, r)
	    < this.evalC(Leader, d, n, r))
	{
	    Leader = (LandTransportation) Contestants.elementAt(i);
	}
    }
    return(Leader);
  }

  // evaluate a given contestant in the auto show
  public int evalC(LandTransportation C, int d, int n, int r)
  {
    if (C == null)
      {return(0);
      }
    else
      {return(C.tripTime(d, r) * C.numVehicles(n) / C.fuel_use());
      }
  }
}
