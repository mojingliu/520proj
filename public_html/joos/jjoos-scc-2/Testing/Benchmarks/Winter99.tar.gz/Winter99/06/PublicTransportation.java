import joos.lib.*;

public class PublicTransportation extends LandTransportation
{
  protected int Schedule;

  public PublicTransportation(String nm, int pass, int spd, int fuel, int safe,
       int rng, String difficult, int exp, String comf, String nte, int whls,
       int sched)
  {
    super(nm, pass, spd, fuel, safe, rng, difficult, exp, comf, nte, whls);
    Schedule = sched;
  }

  public int regularity()
  {
    return Schedule;
  }

  public String toString()
  {
    return("Public " +
	   super.toString() + "  Regularity: " + Schedule + "\n");
  }
}
