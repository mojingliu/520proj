import joos.lib.*;

public class TransTest {
  
  public TransTest() { super(); }

  public static void main(String argv[])
  {
    JoosIO f;
    PrivateVehicle Volkswagen,Ferrari,Cadillac,Chrysler;
    PublicTransportation Bus;
    AutoShow CarORama;
    LandTransportation Winner;
    int dist;
    int refuel;

    f = new JoosIO();

    //  DEFINE THE 5 AUTOSHOW CONTESTANTS:
    Bus = new PublicTransportation("Greyhound",  // Name
				   56,           // Number of Passengers
				   60,           // Speed (mph)
				   12,           // Fuel consumption grade
				   80,           // Safety level
				   600,          // Range of Travel (km)
				   "Fairly Easy",        // Difficulty
				   4,                    // Expense
				   "More Uncomfortable", // Comfort Level
				   "",
				   6,            // Number of Wheels
				   4);           // Regularity
    /* For the private vehicles, parameters are:
 Name, Number of Passengers, Speed (mph), Fuel Consumption grade, Safety Level,
 Range of Travel (miles), Difficulty, Cost grade, Comfort Level,
 Comment, Number of Wheels, Stereo?, Sunroof?
     */
    Volkswagen = new PrivateVehicle("Bug", 4, 55, 25, 5,
				    400, "Moderate", 10, "Med-Uncomfortable",
				    "", 4, true, true);

    Ferrari = new PrivateVehicle("Testarossa", 2, 150, 15, 1,
				 150, "Difficult", 99, "Uncomfortable",
				 "", 4, true, true);

    Cadillac = new PrivateVehicle("El Dorado", 5, 70, 10, 8,
				  250, "Moderate", 25, "Quite Comfortable",
				  "", 4, true, true);

    Chrysler = new PrivateVehicle("MiniVan", 7, 65, 20, 15,
				  400, "Moderate", 15, "Comfortable",
				  "", 4, true, true);
    
    f.println("CAR-O-RAMA AUTO SHOW CONTESTANTS: ");
    // test the toString functions
    f.println(Bus.toString());
    f.println(Volkswagen.toString());
    f.println(Ferrari.toString());
    f.println(Cadillac.toString());
    f.println(Chrysler.toString());

    // add contestants to the autoshow...
    CarORama = new AutoShow(5);
    CarORama.addContestant(Bus);
    CarORama.addContestant(Volkswagen);
    CarORama.addContestant(Ferrari);
    CarORama.addContestant(Cadillac);
    CarORama.addContestant(Chrysler);

    f.println("To transport a family of 6");
    f.println("\tyou need " + Bus.numVehicles(6) + " Greyhound buses.");
    f.println("\tyou need " + Volkswagen.numVehicles(6) + " Volkswagens.");
    f.println("\tyou need " + Ferrari.numVehicles(6) + " Testarossas.");
    f.println("\tyou need " + Cadillac.numVehicles(6) + " El Dorados.");
    f.println("\tyou need " + Chrysler.numVehicles(6) + " Minivans.\n");

    dist = 100;
    refuel = 15;
    // try a while loop and test the tripTime methods
    while (dist <= 600)
      { 
	f.println("Travelling " + dist + " miles (" + refuel +
		  " min refueling breaks) takes:");
	f.println(Bus.tripTime(dist, refuel) + " minutes, roughly " +
		  Bus.tripTimeHours(dist, refuel) + " hours in a Greyhound.");
	f.println(Volkswagen.tripTime(dist, refuel) + " minutes, roughly " +
		  Volkswagen.tripTimeHours(dist, refuel) + " hours in a Bug.");
	f.println(Ferrari.tripTime(dist, refuel) + " minutes, roughly " +
		  Ferrari.tripTimeHours(dist,refuel) + " hours in a Ferrari.");
	f.println(Cadillac.tripTime(dist, refuel) + " minutes, roughly " +
		  Cadillac.tripTimeHours(dist, refuel) +
		  " hours in an Eldorado.");
	f.println(Chrysler.tripTime(dist, refuel) + " minutes, roughly " +
		  Chrysler.tripTimeHours(dist, refuel) +
		  " hours in a Minivan.\n");	
	dist = dist + 100;
      }

    f.println("Judging based on carrying 6 people on a 500-mile trip,");
    f.println("with 15 minute breaks when refueling...");
    Winner = CarORama.judgeContest(500,6,15);
    f.println("And the winner IS: ");
    f.println(Winner.name());

  }
}




