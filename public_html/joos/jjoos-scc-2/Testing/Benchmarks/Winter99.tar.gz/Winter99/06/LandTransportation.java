import joos.lib.*;

public class LandTransportation extends Transportation
{
  protected int Wheels;

  public LandTransportation(String nm, int pass, int spd, int fuel, int safe,
	int rng, String difficult, int exp, String comf, String nte, int whls)
  {
    super(nm, pass, spd, fuel, safe, rng, difficult, exp, comf, nte);
    Wheels = whls;
  }

  public int number_of_wheels()
  {
    return Wheels;
  }
  
  public String toString()
  {
    return("Land Vehicle\n" + "--------------------\n" +
	   super.toString() + "  Number of Wheels: " + Wheels + "\n");
  }
}
