import joos.lib.*;

public class Transportation
{
  protected String Name;
  protected int Passengers;
  protected int Speed;          // mph
  protected int FuelUse;        // scale of 0 to 100
  protected int Safety;         // scale of 0 to 100
  protected int Range;
  protected String Difficulty;
  protected int Expense;        // scale of 0 to 100
  protected String Comfort;
  protected String Notes;

  public Transportation(String nm, int pass, int spd, int fuel, int safe,
             int rng, String difficult, int exp, String comf, String notes) {
    super();
    Name = nm;
    Passengers = pass;
    Speed = spd;
    FuelUse = fuel;
    Safety = safe;
    Range = rng;
    Difficulty = difficult;
    Expense = exp;
    Comfort = comf;
    Notes = notes;
  }

  public String name()       { return(Name); }
  public int passengers()    { return(Passengers); }
  public int speed()         { return(Speed); }
  public int fuel_use()      { return(FuelUse); }
  public int safety()        { return(Safety); }
  public int range()         { return(Range); }
  public String difficulty() { return(Difficulty); }
  public int expense()       { return(Expense); }
  public String comfort()    { return(Comfort); }
  public String notes()      { return(Notes); }

  public int tripTime(int d, int rp) {
    // How many minutes will a Transportation object take to travel a distance
    // of d miles if it takes rp minutes to refuel?
    int time;

    time = (60 * d) / Speed;
    if ((d / Range) > 0 ) {           // Add a penalty of rp minutes for each
      time = time + (d / Range) * rp; // refuelling needed
    }
    if ( ((60 * d) % Speed) > 10) {   // Round up to the next minute
      time = time + 1;
    }

    return (time);
  }

  public int tripTimeHours(int d, int rp) {
    // How many hours will a transportation object to travel a distance of
    // d miles if it takes rp minutes to refuel?
    int minutetime;
    int hourtime;

    minutetime = this.tripTime(d, rp);
    hourtime = minutetime / 60;
    if ((minutetime % 60) > 25 ) { // round up to the next hour
	hourtime = hourtime + 1;
    }
    return (hourtime);
  }

  public int numVehicles(int numpass) {
    // How many vehicles (Transportation objects) are needed to carry
    // numpass passengers?
    int divpass;

    divpass = numpass / Passengers;
    if ((numpass % Passengers) > 0) { // there are remaining passengers
	divpass = divpass + 1;        // who won't fit in a vehicle
    }
    return (divpass);
  }

  public String toString() {
    return ("Name: " + Name +"\n"+ "#Passengers: " + Passengers +"\n"+
	    "Speed: " + Speed +"\n"+ "Fuel Use: " + FuelUse +"\n"+
	    "Safety Level: " + Safety +"\n"+ "Travel Range: " + Range +"\n"+
	    "Difficulty Lvl: " + Difficulty +"\n"+ "Cost: " + Expense +"\n"+
	    "Comfort Level: " + Comfort +"\n"+ "Other: " + Notes + "\n");
  }
}
