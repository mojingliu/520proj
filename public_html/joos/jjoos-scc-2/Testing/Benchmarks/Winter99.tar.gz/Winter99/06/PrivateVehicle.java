import joos.lib.*;

public class PrivateVehicle extends LandTransportation
{
  protected boolean Stereo;
  protected boolean Sunroof;

  public PrivateVehicle(String nm, int pass, int spd, int fuel, int safe,
        int rng, String difficult, int exp, String comf, String nte, int whls,
	boolean ster, boolean sunrf)
  {
    super(nm, pass, spd, fuel, safe, rng, difficult, exp, comf, nte, whls);
    Stereo = ster;
    Sunroof = sunrf;
  }

  public boolean has_stereo()
  {
    return Stereo;
  }

  public boolean has_sunroof()
  {
    return Sunroof;
  }

  public String toString()
  {
    return("Private " +
	   super.toString() + "  Stereo?: " + Stereo + "\n" +
	                      "  Sunroof?: " + Sunroof + "\n");
  }
}
