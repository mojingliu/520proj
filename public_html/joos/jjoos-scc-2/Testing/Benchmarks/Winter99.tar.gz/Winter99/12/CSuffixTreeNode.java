import joos.lib.*;
import java.awt.*;
import java.lang.Math;

public class CSuffixTreeNode
{
  protected int Bindex,Eindex;
  protected CSuffixTreeNode sibling,firstchild;
  
  public CSuffixTreeNode(int b,int e)
    {
      super();
      Bindex=b;
      Eindex=e;
      sibling=null;
      firstchild=null;
    }

  public void setSibling(CSuffixTreeNode s) {sibling=s;}
  public void setFirstchild(CSuffixTreeNode s) {firstchild=s;}

  public int getNumSib()
    {
      if (sibling==null) 
	return 1;
      else 
	return 1+sibling.getNumSib();
    } 

  public int getHeight()
  {
    int sib_h,this_h;

    if (firstchild==null)
      {
	if (sibling==null)
	  return 1;
	else 
	  return sibling.getHeight();
      }
    else 
      {
	if (sibling==null)
	  return 1+firstchild.getHeight();
	else 
	  {
	    sib_h=sibling.getHeight();
	    this_h=firstchild.getHeight()+1;

	    if (sib_h>this_h) 
	      return sib_h;
	    else 
	      return this_h;
	  }
      }
  }

  public CSuffixTreeNode insert(String string,int begin,int end)
    {
      int p1,p2;
      CSuffixTreeNode temp;
      
      p1=Bindex;
      p2=begin;
	
      while ((p1<=Eindex)&&(p2<=end)
	     &&(string.charAt(p1)==string.charAt(p2)))
	{p1++;p2++;}

      if (p1==Bindex)	     /* first characters don't match */
	{
	  if (sibling==null)
	    sibling=new CSuffixTreeNode(begin,end);
	  else 
	    sibling=sibling.insert(string,begin,end);
	}
      else if (p1>Eindex)   /* all characters match */ 
	{
	  if (firstchild==null)
	    firstchild=new CSuffixTreeNode(p2,end);
	  else 
	    firstchild=firstchild.insert(string,p2,end);
	}
      else 
	{		             /* only some characters do match */
	  temp=new CSuffixTreeNode(Bindex,p1-1);
	  Bindex=p1;
	  temp.setSibling(sibling);
	  sibling=null;
	  temp.setFirstchild(this.insert(string,p2,end));
	  return temp;
	}
      return this;
    }

  public void draw(String string,Graphics g,int px,int py,int x,int dx,int dy,
		   boolean vshift)
  {
    int numc,y,sx,sy,strlen;
    FontMetrics f;
    String s;
    JoosConstants   c;

    c=new JoosConstants();
    y=py+dy;
    g.setColor(c.black());

    if (firstchild==null)
      g.drawRect(x-7,y,15,15);

    g.drawLine(px,py,x,y);
    strlen=Eindex+1-Bindex;
    sx=(-strlen*10+px+x)/2;

    if (vshift==true) 
      {sy=y-dy/2;vshift=false;}
    else 
      {sy=y-dy/4;vshift=true;}

    g.setColor(c.blue());
    s=new String(string.substring(Bindex,Eindex+1));
    f=g.getFontMetrics(g.getFont());
    g.fillRect(sx-3,sy-12,f.stringWidth(s)+6,14);
    g.setColor(c.white());
    g.drawString(s,sx,sy);
    
    if (sibling!=null)
      sibling.draw(string,g,px,py,x+dx,dx,dy,vshift);
    
    if (firstchild!=null)
      {
	numc=firstchild.getNumSib();
	firstchild.draw(string,g,x,y,x-dx/2+dx/(numc*2),
			dx/numc,dy,true);
      }
  }
}

