import joos.lib.*;

public class RunMe
{
   public RunMe(){super();}
   public static void main(String args[])
   {    JoosIO f;
	BSTree bst;
	CSuffixTreeFrame suft;
        f = new JoosIO();
	bst = new BSTree();
	bst.test();
        
        f.print("Run in batch (y/n): ");
        if (f.readLine().equals("n"))
          { suft = new CSuffixTreeFrame();
	    suft.test();
          }
   }
}
