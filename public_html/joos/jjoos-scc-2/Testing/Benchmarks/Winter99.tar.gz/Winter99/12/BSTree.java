import joos.lib.*;

public class BSTree
{
    protected BSTreeNode root;
    
    public BSTree()
    {
	super();
	root = null;
    }
    
    public void insert(Object data, MyInteger key) 
    {
	BSTreeNode z;
	BSTreeNode y;
	BSTreeNode x;

	z = new BSTreeNode(data, key, null, null, null);
	y = null;
	x = root;
	
	while (x != null)
	    {
		y = x;
		
		if (z.getKey().compareTo(x.getKey()) < 0)
		    x = x.getLeft();
		else
		    x = x.getRight();
	    }
	
	z.setParent(y);
	
	if (y == null)
	    root = z;
	else
	    {
		if (z.getKey().compareTo(y.getKey()) < 0)
		    y.setLeft(z);
		else

		    y.setRight(z);
	    }
    }

    public void remove(MyInteger key) 
    {
	BSTreeNode z;
	BSTreeNode y;
	BSTreeNode x;

	z =  this.get(key);
	y = null;
	x = null;

	if (z.getLeft() == null || z.getRight() == null)
	    y = z;
	else
	    y = z.successor();

	if (y.getLeft() != null)
	    x = y.getLeft();
	else
	    x = y.getRight();

	if (x != null)
	    x.setParent(y.getParent());

	if (y.getParent() == null)
	    root = x;
	else
	    {
		/* I really want to know if it is physically the same node */
		if (y == y.getParent().getLeft())
		    y.getParent().setLeft(x);
		else
		     y.getParent().setRight(x);
	    }
	
	if (y != z)
	    {
		z.setKey(y.getKey());
		z.setData(y.getData());
	    }
    }
		    
    public BSTreeNode get(MyInteger key) 
    {
	BSTreeNode x;
	x = root;
	
	while ((x != null) && (key.compareTo(x.getKey()) != 0))
	    {
		if (key.compareTo(x.getKey()) < 0)
		    x =  x.getLeft();
		else
		    x = x.getRight();
	    }

	return x;	
    }

    
    /* in this tree, rotate left at node x */
    public void rotateLeft(BSTreeNode x)
    {
	BSTreeNode y;
	y = x.getRight();
	
	x.setRight(y.getLeft());
	
	if (y.getLeft() != null)
	    y.getLeft().setParent(x);

	y.setParent(x.getParent());

	if (x.getParent() == null)
	    root = y;
	else
	    {
		if (x == x.getParent().getLeft())
		    x.getParent().setLeft(y);
		else
		    x.getParent().setRight(y);
	    }

	y.setLeft(x);
	x.setParent(y);
    }	    


    /* in this tree, rotate right at node x */
    public void rotateRight(BSTreeNode x)
    {
	BSTreeNode y;
	y = x.getLeft();
	
	x.setLeft(y.getRight());
	
	if (y.getRight() != null)
	    y.getRight().setParent(x);

	y.setParent(x.getParent());
	
	if (x.getParent() == null)
	    root = y;
	else
	    {
		if (x == x.getParent().getRight())
		    x.getParent().setRight(y);
		else
		    x.getParent().setLeft(y);
	    }
	
	y.setRight(x);
	x.setParent(y);
    }

    public void inOrderWalk()
    {
	root.inOrderWalk(); 
    }

    public void test()
    {
	JoosRandom randnum;
	BSTree bt;
	
	int i;
	int max; 
	max = 25;
	i = 0;
	bt = new BSTree();
	randnum = new JoosRandom(13);

	while (i < max)
	    {
		bt.insert(new Integer(randnum.nextInt()), new MyInteger(randnum.nextInt()));
		i++;
	    }

	bt.inOrderWalk();
    }

}


































