import joos.lib.*;

public class BSTreeNode
{
    protected Object data;
    protected MyInteger key;
    protected BSTreeNode left;
    protected BSTreeNode right;
    protected BSTreeNode parent;
    
    public BSTreeNode()
    {
	super();
	data = null;
	key = null;
	left = null;
        right = null;
	parent = null;
    }

    public BSTreeNode(Object d, 
		      MyInteger k,
		      BSTreeNode l,
		      BSTreeNode r,
		      BSTreeNode p)
    {
	super();
	data = d;
	key = k;
	left = l;
	right = r;
	parent = p;
    }

    public BSTreeNode getLeft() { return left; }

    public BSTreeNode getRight() { return right; }

    public BSTreeNode getParent() { return parent; }

    public Object getData() { return data; }

    public MyInteger getKey() { return key; }

    public void setLeft(BSTreeNode l) { left = l; }

    public void setRight(BSTreeNode r) { right = r; }

    public void setParent(BSTreeNode p) { parent = p; }

    public void setData(Object d) { data = d; }

    public void setKey(MyInteger k) { key = k; }

    public BSTreeNode successor()
    {
	BSTreeNode y;
	BSTreeNode x;

	y = null;
	x = this;

	if (x.getRight() != null)
	    return x.getRight().minimum();

	y = x.getParent();

	while (y != null && x == y.getRight())
	    {
		x = y;
		y = y.getParent();
	    }

	return y;
    }

    public BSTreeNode minimum()
    {
	BSTreeNode x;	 
	x = this;

	while (x.getLeft() != null)
	    {
		x = x.getLeft();
	    }

	return x;
    }
    
    public void inOrderWalk()
    {
	int n;
	String s;
	JoosIO IOobj;
	BSTreeNode x;
	IOobj = new JoosIO();

	if (this.getLeft() != null)
	{
	    x = this.getLeft();
	    x.inOrderWalk();
	}


	n = key.getInt();
	s = data.toString();
	
	IOobj.println("key: " + n);
	IOobj.println("data: " + s);
	
	if (this.getRight() != null)
	{
	    x = this.getRight();
	    x.inOrderWalk();
	}
    }
}








