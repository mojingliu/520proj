public class MyInteger
{
    protected int n;

    public MyInteger() { super(); n = 0; }
    public MyInteger(int i) { super(); n = i; }

    public int compareTo(MyInteger m)
    {
	if (n < m.getInt()) 
	  return -1;
	else if (n > m.getInt()) 
	  return 1;
	else 
	  return 0;
    }
    
    public int getInt()
    {
	return n;
    }
}

