import joos.lib.*;
import java.awt.*;

public class CSuffixTreeFrame extends Frame {
  protected Panel           buttons_panel;
  protected Button          restart_button,next_button;
  protected TextField       textfield;  
  protected String          string;
  protected int             step;
  protected CSuffixTreeNode T;

  protected JoosConstants   c;
  protected JoosContainer   fcontainer;

  public CSuffixTreeFrame() 
    {
      super("JOOS SUFFIXTREE");
      c=new JoosConstants();
      T=null;
      buttons_panel=new Panel();
      buttons_panel.setLayout(new FlowLayout());
      buttons_panel.add(textfield = new TextField("GOLOLGOLOG",10));
      buttons_panel.add(restart_button = new Button("Restart"));
      buttons_panel.add(next_button = new Button("Next >>"));
      next_button.disable();
      textfield.setEditable(true);
      fcontainer=new JoosContainer(this);
      fcontainer.addString("North",buttons_panel);
      this.resize(600,400);
      this.show();
    }
  
  public void test()
    {
      CSuffixTreeFrame f;
      f=new CSuffixTreeFrame();
    }

  public void paint(Graphics g)
    {
      JoosDimension d;
      d = new JoosDimension(this.size());
      g.setFont(new Font("TimesRoman",c.BOLD(),12));

      if (T!=null)
	T.draw(string,g,d.width()/2,80,d.width()/(T.getNumSib()*2),
	       d.width()/T.getNumSib(),(d.height()-120)/(T.getHeight()),
	       true);
    }

  public void restart(String s) 
    {
      if (s.length()>10) 
	string=new String(s.substring(0,9));
      else 
	string=new String(s);

      T=new CSuffixTreeNode(0,string.length()-1);
      step=1;
      this.repaint();
    } 

  public boolean next()
    {
      T=T.insert(string,step,string.length()-1);
      this.repaint();

      if (step==string.length()-1) 
	return false;
      else 
	{
	  step++;
	  return true; 
	}
    }

  public boolean handleEvent(Event event) 
  { 
    JoosEvent je;
    JoosSystem system;
    Object target;
    int id;

    je = new JoosEvent(event);
    system = new JoosSystem();
    target = je.target();
    id = je.id();

    if (id == c.ACTION_EVENT())
      {
	if (target == restart_button) 
	  {
	    next_button.enable();
	    this.restart(textfield.getText());
	  }
	else 
	  if (target == next_button)
	    if (this.next()==false) next_button.disable();
      }
    else 
      if (id == c.WINDOW_DESTROY())
	system.exit(0);

  return true;
  }
}






