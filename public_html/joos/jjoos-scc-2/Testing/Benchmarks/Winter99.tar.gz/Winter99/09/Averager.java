import joos.lib.*;
import java.math.*;
import java.util.*;


public class Averager {
  protected int sum;
  protected int n; 
  protected int sumOfSquares ;
  protected Vector data;
  protected JoosIO f;  

  public Averager(){
      super();
      sum = 0;
      sumOfSquares = 0;
      data = new Vector();
      f = new JoosIO();
  }

  public void addTotalSum(int x) {
      sum = sum + x;
      sumOfSquares = sumOfSquares + x * x;
      data.addElement(new Integer(x));
      n = data.size();
  }

  public void addSumTo(int x){
      int i;
      i = 0;

      while (i<2000)
      {
	 sum = sum + i;
	 sumOfSquares = sumOfSquares + i * i;
         data.addElement(new Integer(i));
	 i = i + 1;
      }
      n = data.size();
  }

  public int addintSum(int x) {
      int intsum, i;
      intsum = 0;
      i = 0;

      while (i<x)
      {
         intsum = intsum + i;
	 i = i + 1; 
      }
      return (intsum);
  }
 
  public JoosFraction getAverage() 
  {
      if (sum % n != 0  )
          return (new JoosFraction(sum, n));
      else 
          return (new JoosFraction(sum/n, 1));
  }


  // problem here is if there is common factor, we can not reduce it
  public JoosFraction intMinusfract(int x, JoosFraction y)
  {
      return(new JoosFraction(x*(y.bot())-y.top(),y.bot()));
  }

  public JoosFraction fractDivint(JoosFraction x, int y)
  {
      return (new JoosFraction(x.top(), x.bot()*y));
  }

  public JoosFraction getDeviation() {
      return this.fractDivint(this.intMinusfract(sumOfSquares, (new JoosFraction(sum*sum, n))), n);
  }  

  public int getNum() { return n; }

  public int getTotalSum() { return sum; }

  public int getSumOfSquares() { return sumOfSquares; }

}
