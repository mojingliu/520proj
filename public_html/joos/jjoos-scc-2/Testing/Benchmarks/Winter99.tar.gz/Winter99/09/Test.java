import joos.lib.*;

public class Test {
    public Test() {
        super();
    }
     
    public static void main(String args[]) {
        JoosIO f; 
	Averager a;
	boolean finish;
	int t, i, j;
	int st, ft;
	JoosFraction jf; 
	JoosSystem js;

	finish = true;
        f = new JoosIO();
	a = new Averager();
	js = new JoosSystem();
   
       f.println("Welcome to S.V.J Averager program!");
       f.println("Please input a set of integer numbers one per line."); 
       f.println("Please input 0 to stop input. ");
       while (finish == true)
       {  
	   t = f.readInt(); 
	   if (t != 0)
	   {
              a.addTotalSum(t);
           } else {
	      finish = false;
	      f.println("End input, now let's see the result we got.\n");  
           }
       }

	f.println("the total number you have input : "+a.getNum());
	f.println("the sum of all numbers is : "+a.getTotalSum());
        f.println("Sum of squares: " + a.getSumOfSquares());

	jf = a.getAverage();
        if (jf.bot() == 1)
	{
            f.println("Cool! You got an integer for the Average!");
	    f.println("the Averager is : " + jf.top());
	} else {
            f.println("Note! You got a decimal Averager number and Joos Do Not support it");
	    f.println("the integer part of Averager is : "+(jf.top()/jf.bot()));
	    f.println("the fraction part of Averager is : "+(jf.top()%jf.bot()) +" div "+jf.bot()); 
	}

	jf = a.getDeviation();
        f.println("The integer part of Deviation square: " + (jf.top()/jf.bot()));
	f.println("the fraction part of Deviation square:"+(jf.top()%jf.bot())+ " div "+jf.bot());

	f.println("\nlet's have some fun! we are going to add 1 upto 2000!");
	f.println("first let's try just adding them up : ");
        st = js.currentTimeMillis() % 10000;
        // f.println("start time at : " + st);
	f.println("the total sum from 1 to 200 is : " + a.addintSum(2000));
	ft = js.currentTimeMillis()%10000;
        // f.println("the finish time at : "+ ft);
        // f.println("total time for addition without saving: "+(ft-st)+" in Milliseconds");
 
        f.println("\nnow let's do something more interesting: ");
	st = js.currentTimeMillis() % 10000;
        // f.println("start time at : " + st);
        a = new Averager();
	a.addSumTo(2000);

        f.println("the sum is : " + a.getTotalSum());
        jf = a.getAverage();
        f.println("the integer part of Averager is : "+(jf.top()/jf.bot()));
        f.println("the fraction part of Averager is : "+(jf.top()%jf.bot()) +" div "+jf.bot());

	jf = a.getDeviation();
        f.println("The integer part of Deviation square: "+(jf.top()/jf.bot()));
	f.println("the fraction part of Deviation square:"+(jf.top()%jf.bot())+ " div "+jf.bot());

	ft = js.currentTimeMillis()%10000;
	//f.println("the finish time at : "+ ft);
	// f.println("total time : "+(ft-st)+" in Milliseconds");
	f.println("\nAll right, Game over now! Bye-Bye!\n");

    }
  }
