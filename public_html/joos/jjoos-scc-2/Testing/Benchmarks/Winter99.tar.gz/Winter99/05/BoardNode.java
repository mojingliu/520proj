//
//
//

import joos.lib.*;
import java.awt.*;
import java.util.Vector;
 
public class BoardNode
{
        protected int boardSize;
      protected Vector queens;
        protected BoardNode next;

        public BoardNode(int board_size)
        {             
            super();
            int i;
                boardSize = board_size;
                queens = new Vector(boardSize);
            /* initialize the queens board */
            for (i=0; i< boardSize; i++)
               queens.addElement(new Integer(0));     

            next = null;
        }

        public void copy(Vector Queens)
        {
                int i;

                for (i=0; i< boardSize; i++)
                        queens.setElementAt(Queens.elementAt(i), i);  
                       /* queens[i] = Queens[i] */
        }
        
        
        
        public BoardNode get_next()
        {
             return next;
        }       
        
        public void next_equal(BoardNode boardN)
        {
            next = boardN;
        }
        
        
        public Vector get_queens()
        {
             return queens;
         }
        
}



