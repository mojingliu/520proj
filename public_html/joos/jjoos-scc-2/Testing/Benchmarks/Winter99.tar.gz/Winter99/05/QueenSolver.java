/*
**     Class Name: QueenSolver  extends Applet
**     Class Intent: Solves the n queens problem by finding and displaying
**      all( or only the unique) solutions for a board of size n (i.e. n queens).  
**     BY: Group 5
**                      Abbas Mahiari  &  Ebrahim Mal-Alla
**     Uses: BoardNode.class and UniqueBoards.class  
**
*/


 
import joos.lib.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.Vector;


public class QueenSolver extends Applet 
{
    /* Class' Fields  */
   protected int boardSize, numOfSols;    /* default: eight queens */
   protected Vector Queens;  
   protected UniqueBoards uniqueSolutions;
   protected TextField n_box, message_box;
   protected Button quit_button, restart_button, next_button;
   protected BoardNode board;
   protected Choice display_choice;
   protected boolean All;
   
   
   public QueenSolver()
   {
        super();
   }
   
   
   
   
     /* the initialize method */
   public void init()
   {
        int i;
        JoosConstants c;

        c = new JoosConstants();
        boardSize=8;
        All = false;        
        numOfSols = 0;    /* number of solutions */
        this.setBackground(c.lightGray()); 
      
        /* the list of unique solutions */
        uniqueSolutions = new UniqueBoards(boardSize);  
        board = null;
        
      Queens = new Vector(boardSize);  /* initialize the queens board */
      for (i=0; i< boardSize; i++)
         Queens.addElement(new Integer(0));     

        this.init_window();
   }/* init() */

    
    //-----------------------------------------> the methods
    /*  initialize the window and bottuns */
   public void init_window()
   {
       Panel option_panel_1;
       JoosConstants c;

       c = new JoosConstants();
      this.setLayout(new FlowLayout(c.FLOWLAYOUT_CENTER(), 23, 10));
      option_panel_1 = new Panel();
      option_panel_1.add(new Label("No. of Queens ="));
      n_box = new TextField("8  ");
      option_panel_1.add(n_box);
      this.add(option_panel_1);
        
        display_choice = new Choice();
        display_choice.addItem("Unique Solutions Only.");
        display_choice.addItem("All Solutions.");
        this.add(new Label("Display :"));
        this.add(display_choice);

      quit_button = new Button("Quit");
        restart_button = new Button("Restart");
        next_button = new Button("Next Solution");
      this.add(quit_button);
      this.add(restart_button);
        this.add(next_button);
 
      message_box = new TextField(68);  /* holds the applet's messages */
        message_box.setEditable(false);
      this.add(message_box);
   }

    /* to handle the mouse events */
   public boolean action(Event e, Object arg) 
   {
      Integer intObj;
      JoosEvent je;
        
      je = new JoosEvent(e);
      message_box.setText(""); 
   
     if (je.target() == restart_button)
     {
            intObj = new Integer(n_box.getText());
            boardSize = intObj.intValue();       /* Get boardSize */ 
               
         
         if (boardSize < 4) 
         {
             message_box.setText("The value of N must be 4 or larger!");
             boardSize = 8;
                 return true;
          };

          n_box.setText("" + boardSize);

          this.restart();
          return true;
      }
      else if (je.target() == quit_button) 
      {
          this.stop();
          return true;
       }
       else if (je.target() == next_button) 
       {
          if (board != null)
          {
              board = board.get_next();
              this.repaint();
           }
           else
              message_box.setText("That's it, no more Solutions!");

           return true;
      }
      else if (je.target() == display_choice)
      {
            if (arg.equals("All Solutions."))
                  All = true;  
             else
                  All = false;
      
          return true;
        } else {
          return false;
        }
   }


   public void restart()
   {
       int i;

       uniqueSolutions = new UniqueBoards(boardSize);
       numOfSols = 0;
       board = null;
message_box.setText(" Runnnig ... Please wait.");
       Queens = new Vector(boardSize);  /* initialize the queens board */
       for (i=0; i< boardSize; i++)
          Queens.addElement(new Integer(0));     

       this.repaint();
   }

   public void stop()
   {   
      JoosSystem s;
      
      s = new JoosSystem();
   
      s.exit(0);
      
      
   }
 
    public void paint(Graphics g)
    {
          int i;
          JoosConstants c;

         c = new JoosConstants();
        if (numOfSols == 0)
        { 
           message_box.setText(" Runnnig ... Please wait.");  
           this.findSolutions(0);
           board = uniqueSolutions.get_solsList();
        }
       
        if (board != null)
        {        
             g.setColor(c.orange().darker());
             g.fill3DRect(21,126,50*boardSize+8,50*boardSize+8, true);
             g.setColor(c.black());
             g.drawRect(25,130,50*boardSize,50*boardSize);
           for (i=0; i < boardSize ; i++) 
           {
              g.setColor(c.black());
              g.drawLine(50*i+25, 130, 50*i+25, 50*boardSize+130);
              g.drawLine(25, 50*i+130, 50*boardSize+25, 50*i+130);
              g.setColor(c.blue().darker());
              g.fillOval(this.intOf((board.get_queens()).elementAt(i))*50+35, i*50+140, 30, 30);
           }
          
           if (!All)
               message_box.setText(" There are a total of " + numOfSols 
                   + " solutions, but only " +uniqueSolutions.get_numOfSols() 
                   + " of them are unique.");
           else
               message_box.setText(" There are a total of " + numOfSols 
                   + " solutions."); 
         }
         else
            message_box.setText(" No more solutions."); 
     } 

        
      /* the heart of the applet: a recursive 
         mathod that finds all the solutions */
     public void findSolutions(int row)
     {
           int i, col;
           boolean valid;
           
           col = 0;
           while (col < boardSize)
           {
               valid = true;
               for (i=1; (i<= row) && (valid == true); i++)
                    if ((this.intOf(Queens.elementAt(i-1)) == col) 
                       || (((col-i) >= 0) && 
                          (this.intOf(Queens.elementAt(row-i)) == col-i))
                       || (((col+i) < boardSize) && 
                          (this.intOf(Queens.elementAt(row-i)) == col+i)) )
                           
                                 valid =false;
                          
                        
                if (valid)
                { 
                    /* Queens[row]= col */
                    Queens.setElementAt(new Integer(col), row); 
                      if (row < boardSize-1)
                      { 
                          this.findSolutions((row=row+1));
                          row = row-1;
                     }  
                     else
                     {
                         numOfSols++;
                           if (All || uniqueSolutions.isUnique(Queens))
                                 uniqueSolutions.add(Queens);
                     }

                 }/* outer if */

                 col++;
          }/* while */

     }/* findSolutions */
      
     public String getAppletInfo()
     {
         return "The N Queens Solver. By Abbas Mahiari & Ebrahim Mal-Alla";

     }


     
public int intOf(Object obj)
{
   Integer intObj;
   
   intObj = new Integer(obj.toString());
  return intObj.intValue();

}

public static void main (String [] args) {
  JoosIO f;
  f = new JoosIO();
  f.println("This is really an applet, this is dummy output");
} 
  
}/*QueenSolver applet*/



