//   Class Name : UniqueBoards
//   Intention: implements collections of "board" that hold the solutions of the 
//              n queens problem (all or unique ones only).
//   BY:   Abbas Mahiari & Ebrahim Mal-Alla 



import joos.lib.*;
import java.awt.*;
import java.applet.Applet;
import java.util.Vector;

public class UniqueBoards
{
        protected int numOfSols, boardSize;    // fields
        protected BoardNode solsList;
 
       // constructor
        public UniqueBoards(int board_size)
        {
                super();
                numOfSols = 0;
                boardSize = board_size;
                solsList = null;
        }
        

        public void add(Vector Queens)   //add a solution.
        {
                BoardNode solution;
                
                solution = new BoardNode(boardSize);
                solution.copy(Queens);  
                solution.next_equal(solsList);
                solsList = solution;
                numOfSols++;
        }
        
        public BoardNode get_solsList()
        {
            return solsList;
        }
        
        public int get_numOfSols()
        {
            return numOfSols;
        }

        public boolean isUnique(Vector Queens)
        {
                 BoardNode temp;
                 
                 temp=solsList;

                while (temp != null)
                {
                        if (this.test1(temp, Queens) || this.test2(temp, Queens)
                         || this.test3(temp,Queens)                                
                         || this.test4(temp, Queens) || this.test5(temp, Queens) 
                         || this.test6(temp, Queens) || this.test7(temp, Queens))
                                return false;
                        temp = temp.get_next();
                }

                return true;
        }



      public int intOf(Object obj)
      {
          Integer intObj;
   
          intObj = new Integer(obj.toString());
          return intObj.intValue();

      }





     /* test the reflection around the x-axis */
     public boolean test1(BoardNode temp, Vector Queens)
     {
        int i;
    
        for (i=0; i< boardSize; i++) 
            if (this.intOf(Queens.elementAt(i)) != 
                        this.intOf(((temp.get_queens()).elementAt(boardSize-i-1))))
               return false;
            
        return true;

      }/* test1 */


      /* test the rotation of 90' */
     public boolean test2(BoardNode temp, Vector Queens)
     {
         int i;
    
         for (i=0; i < boardSize; i++)
               if (this.intOf((temp.get_queens()).elementAt(
                          this.intOf(Queens.elementAt(i)))) != i)
                return false;
                            
         return true;
    
      }/* test2 */




     /* test the reflection about the line y=-x */
     public boolean test3(BoardNode temp, Vector Queens)
     {
        int i;
    
        for (i=0; i < boardSize; i++)
              if (this.intOf((temp.get_queens()).elementAt(boardSize-1-this.intOf     
                                (Queens.elementAt(i)))) != i)
                     return false;
                            
        return true;
        
      }/* test3 */


      /* test the rotation of 270' */
      public boolean test4(BoardNode temp, Vector Queens)
      {
         int i;
     
         for (i=0; i < boardSize; i++)
               if (this.intOf((temp.get_queens()).elementAt(this.intOf(
                     Queens.elementAt(i)))) != (boardSize-1-i))
                     return false;
                            
         return true;
    

       }/* test4 */



      /* test the reflection about the y-axis */
      public boolean test5(BoardNode temp, Vector Queens)
      {
          int i;
    
          for (i=0; i < boardSize; i++)
            if ((boardSize-1 -this.intOf(Queens.elementAt(i)))!= 
                     this.intOf((temp.get_queens()).elementAt(i)))
                  return false;
                            
          return true;
       }/* test5 */




       /* test the reflection about the line y=x */
       public boolean test6(BoardNode temp, Vector Queens)
       {
           int i;
     
           for (i=0; i < boardSize; i++)
             if (this.intOf((temp.get_queens()).elementAt(boardSize-1 - 
                   this.intOf(Queens.elementAt(i))))!= (boardSize-1-i))
                   return false;
                            
           return true;

        }/* test6 */



        /* test the rotation of 180' */
        public boolean test7(BoardNode temp, Vector Queens)
        {
            int i;
     
            for (i=0; i < boardSize; i++)
              if ((boardSize-1- this.intOf(Queens.elementAt(i)))
                           != this.intOf((temp.get_queens()).elementAt(boardSize-1-i)))
                   return false;
                            
            return true;

        }/* test7 */


}



