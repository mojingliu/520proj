/*
File Name       :        ThreePoints.java
Creators        :        Andrew Bogecho (9325667) <andrewb@cs.mcgill.ca>
                         Linda Sun (9525323) <sun@cs.mcgill.ca>
Date            :        January 29, 1999
Version         :        1.0

Known Bugs      :        Currently we cannot perform floating point operations
                         for this reason the initial values have been set to
                         divide into integers.

*/

/* This class will use the MyPoint class to see if there
   are any 3 points in an array of MyPoint that will
   make up a straight line.
*/

import joos.lib.*;

public class ThreePoints {

    protected MyPoint Linda;

    public ThreePoints()
    {
	super();
	Linda = new MyPoint();
    }

    public boolean findLine()
    {
	JoosIO f;
	int tempAx,tempAy,tempBx,tempBy,tempCx,tempCy;
	int i,j,k; // loop counters
	boolean flag; // see if we did find any 
	int grad1,grad2; // The two gradients we will compare
	// temporary variables to see if the gradient is the same

	// Initialize variables
	f = new JoosIO();
	flag = false;
	tempAx=-1;tempAy=-1;tempBx=-1;tempBy=-1;tempCx=-1;tempCy=-1;
	k=0;j=0;
	//f.println("The following points were generated :");
	for(i = 0;i < 10;i++)
	    {
		f.println("Point #" + (i) + ": x = "+Linda.getPointX(i)+", y = "+Linda.getPointY(i));
	    }

	f.println(""); // Print an empty line.

	for(i = 0;i < 8;i++){
	    tempAx = Linda.getPointX(i);
	    tempAy = Linda.getPointY(i);

	    for(j = i+1;j < 9;j++){
		tempBx = Linda.getPointX(j);
		tempBy = Linda.getPointY(j);

		for(k = j+1;k < 10;k++){
		    tempCx = Linda.getPointX(k);
		    tempCy = Linda.getPointY(k);

		    // Calculate the average for the first two points.
		    grad1 = ((tempAx - tempBx)/(tempAy - tempBy));
		    // used for testing
		    //f.println("grad1 = " + grad1);
		    // Calculate the average for the next two points.
		    grad2 = ((tempAx - tempCx)/(tempAy - tempCy));
		    // used for testing
		    //f.println("grad2 = " + grad2);

		    if (grad1 == grad2){
			flag = true;
			f.println("We found three points that are on the same line.");
			f.println("They are :");
			f.println("Point #" + (i) + " " + "x = " + tempAx + " y = " + tempAy);
			f.println("Point #" + (j) + " " + "x = " + tempBx + " y = " + tempBy);
			f.println("Point #" + (k) + " " + "x = " + tempCx + " y = " + tempCy);
			 return flag;
		    }
		}
	    }
	}

	f.println("No three points lie on the same line");
	return flag;

    }

    public static void main(String argv[])
    {
	ThreePoints TP;
	boolean myfinal;

	myfinal = false;  

	TP = new ThreePoints();
	myfinal = TP.findLine();
	// We do not use the value returned. It could be used to denote success or failure.
    }
}
















