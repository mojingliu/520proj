/*
File Name       :        MyPoint.java
Creators        :        Andrew Bogecho (9325667) <andrewb@cs.mcgill.ca>
                         Linda Sun (9525323) <sun@cs.mcgill.ca>
Date            :        January 29, 1999
Version         :        1.0

Known Bugs      :        Currently we cannot perform floating point operations
                         for this reason the initial values have been set to
                         divide into integers.
			 
			 We were unable to get a two dimensional object array
                         which would have been useful for storing the points.
*/

/* Small class to declare our point objects */

import joos.lib.*;

public class MyPoint {
    protected int x0,x1,x2,x3,x4,x5,x6,x7,x8,x9;
    protected int y0,y1,y2,y3,y4,y5,y6,y7,y8,y9;
    // variables for each MyPoint object

    // Constructor for MyPoint
    public MyPoint()
    {
	super();

	// initializing our x and y values
	x0  = 10;y0 = 10;
	x1  = 20;y1 = 20;
	x2  = 50;y2 = 100;
	x3  = 30;y3 = 30;
	x4  = 0;y4 = 0;
	x5  = 0;y5 = 0;
	x6  = 0;y6 = 0;
	x7  = 0;y7 = 0;
	x8  = 0;y8 = 0;
	x9  = 0;y9 = 0;

    }

    // Return the requested x value
    public int getPointX(int Apoint)
    {
        if(Apoint == 0)return x0;
	if(Apoint == 1)return x1;
	if(Apoint == 2)return x2;
	if(Apoint == 3)return x3;
	if(Apoint == 4)return x4;
	if(Apoint == 5)return x5;
	if(Apoint == 6)return x6;
	if(Apoint == 7)return x7;
	if(Apoint == 8)return x8;
	if(Apoint == 9)return x9;

	return 999999; // Means that there was an error
    }

    // Return the requested y value
    public int getPointY(int Apoint)
    {
        if(Apoint == 0)return y0;
	if(Apoint == 1)return y1;
	if(Apoint == 2)return y2;
	if(Apoint == 3)return y3;
	if(Apoint == 4)return y4;
	if(Apoint == 5)return y5;
	if(Apoint == 6)return y6;
	if(Apoint == 7)return y7;
	if(Apoint == 8)return y8;
	if(Apoint == 9)return y9;

	return 999999; // Means that there was an error
    }

}
