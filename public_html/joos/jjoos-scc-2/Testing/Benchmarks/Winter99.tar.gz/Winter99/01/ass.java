import joos.lib.*;
import java.io.*;

// import joos.io.*;
// import joos.util.*;

public class ass {

 public ass() { super(); }

 public static void main(String argv[])
  {
   boolean CountrySrch;
   String SrchStr, InStr, OutStr;
   JoosIO SrchIO;
   JoosRandomAccessFile SrchFile;
   int MatchCount, EntriesTreated;

   SrchIO = new JoosIO();
   SrchFile = new JoosRandomAccessFile("info.in", "r");
   SrchStr = "A";

   while((SrchStr.charAt(0) != 'D') && (SrchStr.charAt(0) != 'C'))
       {
	SrchIO.println("Please enter search type, Domain or Country (D/C)");
	SrchStr = SrchIO.readLine();
	SrchStr = SrchStr.toUpperCase();
       }

   if(SrchStr.charAt(0) == 'D')
       {
	CountrySrch = false;
	SrchStr = "A";
	while((SrchStr.length() <3) || (SrchStr.length() >4))
	    {
	     SrchIO.println("Please enter search domain name (.xx)");
	     SrchStr = SrchIO.readLine();
	     SrchStr = SrchStr.toUpperCase();
	    }
	SrchStr = SrchStr.substring(1,SrchStr.length());
       }
   else
       {
	CountrySrch = true;
	SrchIO.println("Please enter search Country name");
	SrchStr = SrchIO.readLine();
	SrchStr = SrchStr.toUpperCase();
       }

   MatchCount = 0;
   EntriesTreated = 0;
   while(EntriesTreated < 244)
       {
	InStr = SrchFile.readLine();
	if(CountrySrch)
	   {
	    OutStr = "Domain: " + InStr.substring(InStr.length()-2,InStr.length());
	    InStr = InStr.substring(0,InStr.length()-3);
	   }
	else
	   {
	    OutStr = "Country: " + InStr.substring(0,InStr.length()-3);
	    InStr = InStr.substring(InStr.length()-2,InStr.length());
	   }
	InStr = InStr.trim();
	InStr = InStr.toUpperCase();

	if(InStr.compareTo(SrchStr)==0)
	   {
	    SrchIO.println(OutStr);
	    MatchCount++;
	   }
	EntriesTreated++;
       }

   if(MatchCount == 0)
     SrchIO.println("No Entries Matching Srch Found.");
  }
}
