//------------------------------------------------------------------------------
// Class:       Benchmark
//------------------------------------------------------------------------------
// Description: Class contaning main program method. 
//              Reads 3 field records from stdin. Echoes input list then sorts &
//              outputs the list in increasing order 3 times, once for each
//              input field.
//------------------------------------------------------------------------------
// Authors:     Rhodes Brown (9425185) & Jacek Stolcman (9633528) - Group 03
//------------------------------------------------------------------------------

// Imports needed for Java compatibility
import java.util.StringTokenizer;
import joos.lib.*;

public class Benchmark
{
  // Default Constructor
  public Benchmark()
  {
    super();
  }
  
  // Main Program Method
  public static void main(String argv[])
  {
    JoosIO           io;
    String           inputString;
    StringTokenizer  tokenizer;
    RecordList       recordList, sortedList;
    ThreeFieldRecord record;

    io = new JoosIO();

    io.println("Enter records of the form:\n<Fisrt Name> <Last Name> <ID Number>\n");

    inputString = io.readLine();
    tokenizer   = null;
    if (inputString != null)
      tokenizer = new StringTokenizer(inputString, " \t");

    recordList = new RecordList();
    while (tokenizer != null && tokenizer.countTokens() == 3)
    {
      NameField firstName;
      NameField lastName;
      ID_Field  id;

      firstName = new NameField(tokenizer.nextToken(" \t"));
      lastName  = new NameField(tokenizer.nextToken(" \t"));
      id = new ID_Field((new Integer(tokenizer.nextToken(" \t"))).intValue());

      recordList.append(new ThreeFieldRecord(firstName, lastName, id));

      inputString = io.readLine();
      if (inputString != null)
        tokenizer = new StringTokenizer(inputString, " \t");
    }

    io.println("Input:\n");
    io.println(recordList.toString());

    sortedList = recordList.Sort(1);

    io.println("Records sorted by first field (First Name):\n");
    io.println(sortedList.toString());

    sortedList = recordList.Sort(2);

    io.println("Records sorted by second field (Last Name):\n");
    io.println(sortedList.toString());

    sortedList = recordList.Sort(3);

    io.println("Records sorted by third field (ID):\n");
    io.println(sortedList.toString());
  }
}
