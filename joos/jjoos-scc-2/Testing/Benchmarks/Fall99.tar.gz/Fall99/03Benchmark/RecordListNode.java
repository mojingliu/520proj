//------------------------------------------------------------------------------
// Class:       RecordListNode
//------------------------------------------------------------------------------
// Description: Encapsulates record data in a list node
//------------------------------------------------------------------------------
// Authors:     Rhodes Brown (9425185) & Jacek Stolcman (9633528) - Group 03
//------------------------------------------------------------------------------

public class RecordListNode
{
  // Member Data
  protected Record         record;
  protected RecordListNode next;

  // Default Construction
  public RecordListNode()
  {
    super();
    record = null;
    next   = null;
  }

  // Construction: single element
  public RecordListNode(Record record_)
  {
    super();
    record = record_;
    next   = null;
  }

  // Read Access Method
  public Record Record()
  {
    return record;
  }

  // Read Access Method
  public RecordListNode Next()
  {
    return next;
  }

  // Write Access Method
  public void SetNext(RecordListNode newValue)
  {
    next = newValue;
  }
}
