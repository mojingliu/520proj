//------------------------------------------------------------------------------
// Class:       NameField
//------------------------------------------------------------------------------
// Description: Record field containing an name string.
//------------------------------------------------------------------------------
// Authors:     Rhodes Brown (9425185) & Jacek Stolcman (9633528) - Group 03
//------------------------------------------------------------------------------

public class NameField extends Field
{
  // Member Data
  protected String name;

  // Construction
  public NameField(String rhs)
  {
    super();
    name = rhs;
  }

  // Overridden Comparison Function
  public boolean LessThan(Field rhs)
  {
    NameField local;

    local = (NameField) rhs;
    return (name.compareTo(local.toString()) < 0);
  }

  public String toString()
  {
    return name;
  }
}
