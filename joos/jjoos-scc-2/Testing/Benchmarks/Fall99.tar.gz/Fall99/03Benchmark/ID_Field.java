//------------------------------------------------------------------------------
// Class:       ID_Field
//------------------------------------------------------------------------------
// Description: Record field containing an integer ID.
//------------------------------------------------------------------------------
// Authors:     Rhodes Brown (9425185) & Jacek Stolcman (9633528) - Group 03
//------------------------------------------------------------------------------

public class ID_Field extends Field
{
  // Member Data
  protected int id;

  // Construction
  public ID_Field(int rhs)
  {
    super();
    id = rhs;
  }

  // Read Access Method
  public final int Value()
  {
    return id;
  }

  // Overridden Comparison Function
  public boolean LessThan(Field rhs)
  {
    ID_Field local;

    local = (ID_Field) rhs;
    return (id < local.Value());
  }

  public String toString()
  {
    return (new Integer(id)).toString();
  }
}
