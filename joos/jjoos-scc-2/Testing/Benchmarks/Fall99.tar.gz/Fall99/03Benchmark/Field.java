//------------------------------------------------------------------------------
// Class:       Field
//------------------------------------------------------------------------------
// Description: Abstract class used as an interface to various record fields.
//------------------------------------------------------------------------------
// Authors:     Rhodes Brown (9425185) & Jacek Stolcman (9633528) - Group 03
//------------------------------------------------------------------------------

public abstract class Field
{
  // Default Constructor
  public Field()
  {
    super();
  }

  // Comparison Function: to be overridden
  public abstract boolean LessThan(Field rhs);
}
