//------------------------------------------------------------------------------
// Class:       RecordList
//------------------------------------------------------------------------------
// Description: Implements a singly linked list of records.
//              Supports insertion at the beginning and end of the list.
//              Implements a recursive merge sort according to a given field
//              position.
//------------------------------------------------------------------------------
// Authors:     Rhodes Brown (9425185) & Jacek Stolcman (9633528) - Group 03
//------------------------------------------------------------------------------

// Imports needed for Java compatibility
import joos.lib.*;

public class RecordList
{
  // Member Data
  protected RecordListNode head, tail;
  
  // Default Construction
  public RecordList()
  {
    super();
    head = tail = null;
  }

  // Copy Construction
  public RecordList(RecordList rhs)
  {
    super();
    head = rhs.Head();
    tail = rhs.Tail();
  }

  // Construction: single element
  public RecordList(Record record)
  {
    super();
    head = tail = new RecordListNode(record);
  }

  // Construction: from already linked nodes
  public RecordList(RecordListNode head_, RecordListNode tail_)
  {
    super();
    head = head_;
    tail = tail_;
  }

  // Read Access Method
  public RecordListNode Head()
  {
    return head;
  }

  // Read Access Method
  public RecordListNode Tail()
  {
    return tail;
  }

  public int length()
  {
    int            len;
    RecordListNode current;

    if (head == null)
      return 0;

    len     = 1;
    current = head;
    while (current != tail)
    {
      len = len + 1;
      current = current.Next();
    } 

    return len;
  }

  public void insert(Record record)
  {
    RecordListNode tmp;

    tmp = new RecordListNode(record);
    if (head == null)
      head = tail = tmp;
    else
    {
      tmp.SetNext(head);
      head = tmp;
    }
  }

  public void append(Record record)
  {
    RecordListNode tmp;

    tmp = new RecordListNode(record);
    if (head == null)
      head = tail = tmp;
    else
    {
      tail.SetNext(tmp);
      tail = tmp;
    }
  }

  // Merge Sort: return sorted list
  //
  // Notes: The appendFirst and appendSecond variables are used
  //        as a hack, since the do-while and break statements are
  //        not implemented in the A- JOOS compiler.
  public RecordList Sort(int fieldId)
  {
    RecordListNode first, second;
    RecordListNode firstEnd, secondStart;
    RecordList     firstList, secondList, sortedList;
    boolean        appendFirst, appendSecond;
    int            i, half;

    if (head == tail)
    {
      return new RecordList(this);
    }

    // Find the half-way point in the list
    i = 1;
    firstEnd = head;
    half = (this.length() / 2);
    while (i < half)
    {
      firstEnd = firstEnd.Next();
      i = i + 1;
    }
    secondStart = firstEnd.Next();

    // Recurse on the 1st half then the 2nd half of the list
    firstList  = (new RecordList(head, firstEnd)).Sort(fieldId);
    secondList = (new RecordList(secondStart, tail)).Sort(fieldId);

    first  = firstList.Head();
    second = secondList.Head();
    appendFirst  = false;
    appendSecond = false;
    sortedList   = new RecordList();

    // Merge sub-lists
    while (!appendFirst && !appendSecond)
    {
      if (first.Record().Field(fieldId).LessThan(
          second.Record().Field(fieldId)))
      {
        sortedList.append(first.Record());
        if (first == firstList.Tail())
          appendSecond = true;           // break from loop
        else
          first = first.Next();
      }
      else
      {
        sortedList.append(second.Record());
        if (second == secondList.Tail())
          appendFirst = true;            // break from loop
        else
          second = second.Next();
      }
    }

    // Append remaining list
    while (appendFirst)
    {
      sortedList.append(first.Record());
      if (first == firstList.Tail())
        appendFirst = false;             // break from loop
      else
        first = first.Next();
    }

    // Append remaining list
    while (appendSecond)
    {
      sortedList.append(second.Record());
      if (second == secondList.Tail())
        appendSecond = false;            // break from loop
      else
        second = second.Next();
    }

    return sortedList;
  }

  public String toString()
  {
    String         output;
    RecordListNode current;

    output = "";

    current = head;
    while (current != null)
    {
      output = output + current.Record().toString() + "\n";
      current = current.Next();
    } 

    return output;
  }
}
