//------------------------------------------------------------------------------
// Class:       Record
//------------------------------------------------------------------------------
// Description: Abstract class used as an interface to various record types.
//------------------------------------------------------------------------------
// Authors:     Rhodes Brown (9425185) & Jacek Stolcman (9633528) - Group 03
//------------------------------------------------------------------------------

public abstract class Record
{
  // Construction
  public Record()
  {
    super();
  }

  // Read Access Method: to be overridden
  public abstract Field Field(int fieldId);
}
