//------------------------------------------------------------------------------
// Class:       ThreeFieldRecord
//------------------------------------------------------------------------------
// Description: Record containing exactly 3 fields.
//------------------------------------------------------------------------------
// Authors:     Rhodes Brown (9425185) & Jacek Stolcman (9633528) - Group 03
//------------------------------------------------------------------------------

public class ThreeFieldRecord extends Record
{
  // Member Data
  protected Field first;
  protected Field second;
  protected Field third;

  // Construction
  public ThreeFieldRecord(Field first_, Field second_, Field third_)
  {
    super();

    first  = first_;
    second = second_;
    third  = third_;
  }

  // Read Access Method
  public Field Field(int fieldId)
  {
    if (fieldId == 1)
      return first;
    else if (fieldId == 2)
      return second;
    else if (fieldId == 3)
      return third;
    else
      return null;
  }

  public String toString()
  {
    return (first.toString()  + "\t" +
            second.toString() + "\t" +
            third.toString());
  }
}
