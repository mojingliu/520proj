import java.util.*;
import joos.lib.*;

public class Index {

	protected String text;
	protected Node tree;

	public Index (String t) {
		super();
		text = t;
		tree = new Node(null, null, null);
		this.makeIndexTree();
	}
	
	public void makeIndexTree() {
	
		StringTokenizer getLine ;
		StringTokenizer getWord ;
		String mot;
		int line;
		
		line = 0;
		getLine = new StringTokenizer (text, "\n");
		while (getLine.hasMoreTokens()) {
			line++;
			getWord = new StringTokenizer ((String) getLine.nextElement()," ,.;:'?!=+-_");
			while (getWord.hasMoreTokens()) {
				mot = (String) getWord.nextElement();
			        tree.add_elem(mot, line);
			}
	}	 
	}
	public void display() {
		JoosIO f;
		
		f = new JoosIO();
		if (tree.getElem()!=null) {
			f.println(tree.toString());
		}
		else {
			f.println("The text is empty");
		}	
	}

	public String find(String word) {
		Element target;
		
                target = null;
		if ((tree==null)||((target = tree.find(word)) == null))
			return "";			
                else
                  return target.displayLine();
	}

	
}
