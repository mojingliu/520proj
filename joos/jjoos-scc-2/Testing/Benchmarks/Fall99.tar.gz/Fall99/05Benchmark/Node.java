import joos.lib.*;
import java.lang.*;
import java.util.*;

public class Node {
	
	protected Element elem;
	protected Node lson;
	protected Node rson;

	public Node(Element e, Node ls, Node rs) {
		super();
		elem = e;
		lson = ls;
		rson = rs;
	}

	public Element getElem() {
		return elem;
	}	

	public void add_elem(String mot, int line) {
		if (elem!=null) {
			if (( mot. compareTo(elem.getName()) ) < 0) {
				if (lson!=null) {
					lson.add_elem(mot, line);
				}
				else {
					lson = new Node(new Element (mot, line),null,null);
				}	
			}

			if (( mot.compareTo(elem.getName()) ) == 0){
				elem.add_line(line);
			}
			
			if  (( mot. compareTo(elem.getName()) ) > 0){
				if (rson!=null) {
					rson.add_elem(mot, line);
				}
				else {
					rson = new Node(new Element (mot, line),null,null) ;
				}	
			}	
		}
		else {
			elem = new Element(mot, line);
		}	
	}

	public String go_through(String result) {
		Vector v;
		
		if (lson!=null) {
			result = lson.go_through(result);
		}
		result = result + "\n" + elem.getName() + "\t\t : # " + elem.displayLine() ;	
		if (rson!=null) {
			result = rson.go_through(result);
		}
		return result;
	}
	
	
	public String toString() {
		String result ;
		result = "The Index of the input text is : ";
		result = this.go_through(result);
		return result;
	}

	public Element find(String word) {
		int compar;

		if (elem!=null) {
			compar = elem.getName().compareTo(word);
		
			if (compar == 0)
				return elem;
			
			else if (compar > 0) {
				if (lson == null)
					return null;
				return lson.find(word);
			}
			else {
				if (rson == null)
					return null;
				return rson.find(word);
			}
		}
		else {
			return null;
		}
	}

}	
