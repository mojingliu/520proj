import joos.lib.*;
import java.io.*;

public class Main {

	public Main() {
		super();
	}	
	
	public static void main(String argv[]) {
		String lin1;
		String lin;
		Index index;
		JoosIO f;
		int nblin;
		String tgtlinenbs;
		
		f = new JoosIO();
		lin = "";
		nblin = 0;
		lin1 = f.readLine();
		while (lin1.length() != 0) {
			nblin++;
			lin = lin + "\n" + lin1;
			lin1 = f.readLine();
		}
		index = new Index(lin);
		lin1 = f.readLine();
		tgtlinenbs = index.find(lin1);
		index.display();
		if (tgtlinenbs.length() == 0)
			f.println("word '"+lin1+"' not found!");
		else
			f.println("word '"+lin1+"' found at lines " 
				+ tgtlinenbs+".");
	}
}	

