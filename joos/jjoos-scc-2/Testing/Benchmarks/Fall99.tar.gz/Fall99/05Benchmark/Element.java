import java.util.*;

public class Element {

	protected String name;
	protected Vector vect_line;

	public Element(String n, int line) {
		super();
		name = n;
		vect_line = new Vector();
		vect_line.addElement(new Integer(line));
	}

	public String getName() {
		return name;
	}


	public void add_line( int line) {
		vect_line.addElement(new Integer(line));
	}
	
	public String displayLine() {
		int vectsize;
		int i;
		String result;
		
		i = 0;
		result = "";
		if (vect_line!=null) {
			if (!(vect_line.isEmpty())) {
				vectsize = vect_line.size();
				while (i<(vectsize-1)) {
					result = result + ((Integer) vect_line.elementAt(i)).intValue() + ", ";
					i = i+1;
				}
				result = result +((Integer) vect_line.elementAt(vectsize-1)).intValue();
			}
		}
		return result;
	}	
}
