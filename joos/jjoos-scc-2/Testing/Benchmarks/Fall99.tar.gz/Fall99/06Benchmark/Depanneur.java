import joos.lib.*;

public class Depanneur {	
 
 	
	protected Article Banana ;
   	protected Article Orange ;
	protected Article Mango ;
	protected Article WaterMelon ;

	protected Article Carot;
	protected Article Onion ; 
	protected Article Tomato;
	protected Article Lemon ; 
	
	protected Article Mars ; 
	protected Article Twix ; 
	protected Article Bounty ; 
	
	protected Article MrClean ; 
	protected Article Tide ; 
	protected Article Ajax ; 
	
	public Depanneur() { 

	super(); 
	
        Banana = new Article(1,20,"Fruit","Banana"); //The depanneur has 20 lemmon and The cost is 1$ each
        Orange = new Article(1,30,"Fruit","Orange");
        Mango = new Article(2,10,"Fruit","Mango");
        WaterMelon = new Article(3,5,"Fruit","Water Melon");
        
        Carot = new Article(1,50,"Vegetable","Carot");
        Onion  = new Article(1,50,"Vegetable","Onion");
        Tomato = new Article(2,50,"Vegetable","Tomato");
        Lemon  = new Article(1,20,"Vegetable","Lemon"); //The depanneur has 20 lemmon and The cost is 1$ each
        
        Mars  = new Article(2,20,"Chocolate","Mars");
        Twix  = new Article(1,30,"Chocolate","Twix");
        Bounty  = new Article(3,50,"Chocolate","Bounty");
        
        MrClean  = new Article(5,15,"Cleaning_Stuff","Mr Clean");
        Tide = new Article(6,16,"Cleaning_Stuff","Tide");
        Ajax  = new Article(7,17,"Cleaning_Stuff","Ajax");

	}

    
 public Article GetBanana(){
	return(Banana);
	}

public Article GetOrange(){
        return(Orange); 
        }
public Article GetMango(){
        return(Mango); 
        }

public Article GetWaterMelon(){
        return(WaterMelon); 
        }

public Article GetCarot(){
        return(Carot); 
        }

public Article GetOnion(){
        return(Onion); 
        }

public Article GetTomato(){
        return(Tomato); 
        }

public Article GetLemon(){
        return(Lemon); 
        }

public Article GetMars(){
        return(Mars); 
        }

public Article GetTwix(){
        return(Twix); 
        }

public Article GetBounty(){
        return(Bounty); 
        }

public Article GetMrClean(){
        return(MrClean); 
        }

public Article GetTide(){
        return(Tide); 
        }

public Article GetAjax(){
        return(Ajax); 
        }

}

