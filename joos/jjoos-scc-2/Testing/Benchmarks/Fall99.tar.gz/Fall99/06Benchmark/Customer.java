import java.util.*;
import java.text.*;
import joos.lib.*;

public  class Customer{
	
	protected int  budget; 
		
	protected String name ;
			
	protected String basket;
  		
	public Customer () {
		
		super();

		budget = 0;
		name = null;
		basket = "";
} 
	

	public  void Print_Articles(Depanneur depanneur,JoosIO f){
	
	f.println("Please enter the number corresponding to the article you want to buy:");
	f.println("If you are done, enter -1");
	f.println(" ");
		
	f.println("			Article:	Price:");
	if ( (depanneur.GetBanana()).GetNumber() > 0 &&  budget >= (depanneur.GetBanana()).GetPrice() ){
		f.println("Fruits:			1) Banana 	1$");}
        if ( (depanneur.GetOrange()).GetNumber() > 0 &&  budget >= (depanneur.GetOrange()).GetPrice() ){
		f.println("			2) Orange 	1$");}
        if ( (depanneur.GetMango()).GetNumber() > 0 &&  budget >= (depanneur.GetMango()).GetPrice() ){
		f.println("			3) Mango	2$  ");}
        if ( (depanneur.GetWaterMelon()).GetNumber() > 0 &&  budget >= (depanneur.GetWaterMelon()).GetPrice() ){
		f.println("			4) WaterMelon	3$");}
        if ( (depanneur.GetCarot()).GetNumber() > 0 &&  budget >= (depanneur.GetCarot()).GetPrice() ){
		f.println("Vegetables:		5) Carot 	1$");}
        if ( (depanneur.GetOnion()).GetNumber() > 0 &&  budget >= (depanneur.GetOnion()).GetPrice() ){
    		f.println("			6) Onion	1$");}
        if ( (depanneur.GetTomato()).GetNumber() > 0 &&  budget >= (depanneur.GetTomato()).GetPrice() ){
   		f.println("			7) Tomato	2$");}
        if ( (depanneur.GetLemon()).GetNumber() > 0 &&  budget >= (depanneur.GetLemon()).GetPrice() ){
    		f.println("			8) Lemon	1$");}
        if ( (depanneur.GetMars()).GetNumber() > 0 &&  budget >= (depanneur.GetMars()).GetPrice() ){
		f.println("Chocolates:		9) Mars		2$");}
        if ( (depanneur.GetTwix()).GetNumber() > 0 &&  budget >= (depanneur.GetTwix()).GetPrice() ){
		f.println("			10) Twix	1$");}
        if ( (depanneur.GetBounty()).GetNumber() > 0 &&  budget >= (depanneur.GetBounty()).GetPrice() ){
		f.println("			11) Bounty	3$");}
        if ( (depanneur.GetMrClean()).GetNumber() > 0 &&  budget >= (depanneur.GetMrClean()).GetPrice() ){
		f.println("Cleaning_Stuff:		12) MrClean	5$");}
        if ( (depanneur.GetTide()).GetNumber() > 0 &&  budget >= (depanneur.GetTide()).GetPrice() ){
		f.println("			13) Tide	6$");}
        if ( (depanneur.GetAjax()).GetNumber() > 0 &&  budget >= (depanneur.GetAjax()).GetPrice() ){
		f.println("			14) Ajax	7$");}
	  }
	

 public void SetBudget(int i){
	budget = i;
	}

public int GetBudget(){
	return(budget);
	}

public String GetBasket(){
        return(basket);
        }       

public void SetName(String i){
        name = i;
        }
public String GetName(){
        return (name);
        }

 public  void Buy(Article article,JoosIO f){
			 if( (budget - article.GetPrice()) >= 0){
			 	budget = budget - article.GetPrice(); //Decrement budget by price of banana
			   article.SetNumber( article.GetNumber() - 1);
			   basket = basket+ "--"+"one " + article.GetName() ; 
			  f.println("---------------------------------------------------------"); 
			  f.println("You have just bought one " +  article.GetName() );
										
				}
			 else f.println("Sorry you don't have enought money to pursue this product");
		                                         
			 }
				
 public static void main(String argv[]){
		JoosIO f;
   		int article_number;
		int leave;
		Depanneur depanneur;
		Customer customer;
		

		article_number = 0;
	

		f = new JoosIO();		
		depanneur = new Depanneur();
		customer = new Customer();		

		f.println("Please my friend enter your name");
		customer.SetName(f.readLine());
		f.println("Please enter your budget, it has to be an integer:"); 
		customer.SetBudget(f.readInt());
		
		leave = 0;
		f.println("---------------------------------------------------------"); 
		f.println("		 Hello " + customer.GetName() );
		f.println("	Long Time no see my friend , where have you been?   ");
                f.println("---------------------------------------------------------");
		while ( (customer.GetBudget() > 0) && (leave == 0)) {
			
		customer.Print_Articles(depanneur,f);
		
		article_number = f.readInt();
		
		if (article_number==1){customer.Buy(depanneur.GetBanana(),f);};
		if (article_number==2){ customer.Buy(depanneur.GetOrange(),f);};
		if (article_number==3){ customer.Buy(depanneur.GetMango(),f);};
		if (article_number==4){ customer.Buy(depanneur.GetWaterMelon(),f);};
		if (article_number==5){ customer.Buy(depanneur.GetCarot(),f);};
		if (article_number==6){ customer.Buy(depanneur.GetOnion(),f);};
		if (article_number==7){ customer.Buy(depanneur.GetTomato(),f);};
		if (article_number==8){ customer.Buy(depanneur.GetLemon(),f);};
		if (article_number==9){ customer.Buy(depanneur.GetMars(),f);};
		if (article_number==10){ customer.Buy(depanneur.GetTwix(),f);};
		if (article_number==11){ customer.Buy(depanneur.GetBounty(),f);};
		if (article_number==12){ customer.Buy(depanneur.GetMrClean(),f);};
		if (article_number==13){ customer.Buy(depanneur.GetTide(),f);};
		if (article_number==14){ customer.Buy(depanneur.GetAjax(),f);};
		if (article_number==-1){ leave = 1;};
		
		
	
		f.println( "Your remaining budget is :" + customer.GetBudget());
		f.println("---------------------------------------------------------");

				}
	
		if ((customer.GetBudget() == 0) || (leave == 1)){
			f.println("---------------------------------------------------------");
			f.println("The articles you bought are:");
			if (customer.GetBasket() == "")
			    f.println("Nothing");
			else f.println(customer.GetBasket());
			f.println("--------Thanks " + customer.GetName() + ",come back when ever you want--------");
			f.println("----------------see you soon-----------------------------");
			}	

		}
		
}			
			  				
			
			
			
			
							 
		
		
	
		
			
		
		
	
