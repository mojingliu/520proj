import joos.lib.*;

public class Article { 

        protected int price;
        protected int number;
        protected String kind;
        protected String name;

        public Article (int ArticlePrice, int ArticleNumber, String ArticleKind, String ArticleName){
                super();
                price=ArticlePrice;
                number=ArticleNumber;
                kind=ArticleKind;
		name = ArticleName;
        
 }
public int GetNumber(){
         return (number) ;
	}

public int GetPrice(){                 
         return (price) ;                         
        }

public void SetNumber(int i){
	number = i;
}

public String GetName(){
	return (name);
	}

}

