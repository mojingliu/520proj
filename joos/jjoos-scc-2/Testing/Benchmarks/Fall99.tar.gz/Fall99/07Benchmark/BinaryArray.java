// File BinaryArray.java
//
// The Binary class describes the object used to do binary operations
// This input must be a file in which Decryption has written its output
//


import joos.lib.*;
import java.util.*;                                                             
import java.io.*;

public class BinaryArray {

    protected String myArray;

    public BinaryArray() {
	super();
	myArray = new String();
    }

    public BinaryArray(String binaryString) {
	super();
	myArray = new String(binaryString);
    }

    // concat: concatenates 2 bibaryArray
    public BinaryArray concat(BinaryArray b) {
	String s;
	s = myArray.concat(b.toString());
	return new BinaryArray(s);
    } 

    // generateKey: creates a random key for the BinaryArray
    public BinaryArray generateKey() {
	String s;
	Random rnd;
	int i;

	s = new String();
	rnd = new Random();

	i = 0;

	while ( i < myArray.length()) {
	    if (rnd.nextInt() < 0)
		s=s.concat("0");
	    else
		s=s.concat("1");
	    i = i + 1;
	}

	return new BinaryArray(s);
    }

    // length: returns the length of the BinaryArray
    public int length() {
	return myArray.length();
    }

    // subArray: extracts  a part of the BinaryArray
    public BinaryArray subArray(int beginIndex, int endIndex) {
	return new BinaryArray(myArray.substring(beginIndex, endIndex));
    }

    // toString: overrides objet
    public String toString() {
	return myArray;
    }

    // xOR: does XOR operation with another BinaryArray
    public BinaryArray xOR(BinaryArray b) {
	String sb;
	String sResult;
	int i;

	String newKey;

	newKey = new String();

	sb = b.toString();
	sResult = new String();

	// ugly trick to avoid non-printable characters which come from 
	// the .key file
	i = 0 ;
	while (i<sb.length()) {
	 
	    if ( sb.charAt(i) == '0')
		newKey = newKey.concat("0");
	    if ( sb.charAt(i) == '1')
		newKey = newKey.concat("1");
	    i = i+1;
	}
  
	sb = newKey;
	

	i = 0;
	while ( i < myArray.length()) {
	   	   
	      if (myArray.charAt(i) == sb.charAt(i))
		  sResult = sResult.concat("0");
	      else
		  sResult = sResult.concat("1");
	      
	      i = i + 1;
	}	
	
	return new BinaryArray(sResult);
    }

}
