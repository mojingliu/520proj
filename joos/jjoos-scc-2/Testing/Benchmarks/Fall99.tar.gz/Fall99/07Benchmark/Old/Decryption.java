// file Decryption.java
//
// The Decryption class takes input from stdin
// This input must be a file in which Decryption has written its output
//
// Usage: java Encryption < inPutFilefromEncryption
//

import joos.lib.*;
import joos.group07.*;
import java.util.*;

public class Decryption {

  public Decryption()  { super(); }

  public static void main(String argv[]) { 
    JoosIO f;
    String stringInput;
    String stringOutput;
    BinaryArray binaryInput;
    BinaryArray binaryOutput;
    BinaryArray binaryKey;

    JoosCharacterBinaryConverter converter;
    int i;
    String sBuffer;
    char c;
    Character ch;

    f = new JoosIO();
    converter = new JoosCharacterBinaryConverter();

    // read the BinaryArray of the file
    binaryInput = new BinaryArray(f.readLine());

    // read the key in .key
    binaryKey=binaryInput.loadKey();

    // Decrypt the ciphertext
    binaryOutput = binaryInput.xOR(binaryKey);
 
    stringOutput = new String();
    i = 0;
    while (i < binaryOutput.length()) {
	
	// translating binary to ascii
	c = converter.binary2Character((binaryOutput.subArray(i, i+8)).toString());
	ch = new Character(c);
	stringOutput = stringOutput.concat(ch.toString());
	
	i = i + 8;
    }

    // print the decrypted text in stdout
    f.println(stringOutput);
  }
}
