// file JoosCharacterBinaryConverter.java
//
// this file has been written in java to do char 
// to Binary String conversion
//
 

package joos.group07;

public class JoosCharacterBinaryConverter {

    public JoosCharacterBinaryConverter() {}

    public String character2Binary(char c) {
	String s1 = Integer.toBinaryString((int) c);
	String s2 = "00000000";
	s1 = s2.concat(s1);
	return s1.substring(s1.length()-8);
    }

    // converts a binary string to char
    public char binary2Character(String s) {
	int i = 0;
	try {
	    i = Integer.parseInt(s, 2);
	} catch ( NumberFormatException e ) {}
	
	return  (char) i;
    }

    // converts a char to a binary string
    public char binary2Character(Object o) {
	return binary2Character( (String) o);
    }
}
