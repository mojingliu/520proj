// File TestBoth.java
//
// The Encryption class takes input from stdin, generates a key for the 
// plaintext, generates ciphertext, and then decrypts, putting decrypted
// text on stdout
//
// Usage: java TestBoth < inPutFile
//

import joos.lib.*;
import joos.group07.*;
import java.util.*;

public class TestBoth {

  public TestBoth()  { super(); }

  public static void main(String argv[]) { 
    JoosIO f;
    String stringInput;
    String stringOutput;
    BinaryArray binaryInput;
    BinaryArray binaryOutput;
    BinaryArray newbinaryInput;
    BinaryArray binaryKey;
    JoosCharacterBinaryConverter converter;
    int i;
    String sBuffer;
    char c;
    Character ch;


    f = new JoosIO();
    binaryInput = new BinaryArray();
    converter = new JoosCharacterBinaryConverter();

    // read stdin
    while ( ( stringInput = f.readLine() ) != null ) {
	    
	i = 0;

	// convert stdin to BinaryArray
	while (i < stringInput.length()) {
	    sBuffer = converter.character2Binary(stringInput.charAt(i));
	    binaryInput = binaryInput.concat(new BinaryArray(sBuffer));
		
	    i = i + 1;
	}
	// we add the '\n' cut by readln 
	sBuffer = converter.character2Binary('\n');
	binaryInput = binaryInput.concat(new BinaryArray(sBuffer));	

    }

    // Generation of the key
    binaryKey=binaryInput.generateKey();

    // Encryption of the input
    binaryOutput = binaryInput.xOR(binaryKey);

    // Decrypt the ciphertext
    newbinaryInput = binaryOutput.xOR(binaryKey);
    
    stringOutput = new String();
    i = 0;
    while (i < binaryOutput.length()) {
        // translating binary to ascii
        c = converter.binary2Character(
                (newbinaryInput.subArray(i,i+8)).toString());      
        ch = new Character(c);
        stringOutput = stringOutput.concat(ch.toString());
        i = i + 8;
    }   
    
    // print the decrypted text in stdout
    f.println(stringOutput);
  }
}
