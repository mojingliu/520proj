/* Here we use simple prime to do calculate directly, complex prime can use extended class of RSA to generate large primes.      
   Here we will use primes p = 11, q = 29, so n = 319, and public key e = 3
   secret key d = 187
*/

import joos.lib.*;
import RSA;

public class encry {
    public encry()
    { super() ; }

    public static void main(String[] args)
    {   
        JoosIO f ;
        RSA rsa ;
        String src, dest ;

        f = new JoosIO() ;
        rsa = new RSA(11, 19) ;

        src = f.readLine() ;

        if (!rsa.setPubKey(7))
        { f.println ("Invalid public key.") ; 
          return ;
        }
        
        if (!rsa.setSecKey(103))
        { f.println ("Invalid secret key.") ; 
          return ;
        }

        dest = rsa.encryption(src) ;
        f.println (dest) ;
        
    }
} 
    
