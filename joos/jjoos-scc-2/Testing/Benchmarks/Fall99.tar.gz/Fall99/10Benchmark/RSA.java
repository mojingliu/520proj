import joos.lib.*; 

public class RSA{
    protected int p, q, n, e, d ;
    protected int step ;

    public RSA(int pi, int qi)
    {
        super () ;
        p = pi ;
        q = qi ;
        n = pi*qi ;
        step = 1 ;
    }

    public boolean setPubKey(int ei)
    {
        int deltan ;  
    
        deltan = (p-1)*(q-1) ;
        if ( this.gcd(deltan, ei)==1 )
        { // a is relatively prime to deltan
            e = ei ;
            step = 2 ;
            return true ;
        }
        else
            return false ;
    }
  
    public boolean setSecKey (int di)
    {
        int deltan ;
        int tempi ;

        deltan = (p-1)*(q-1) ; 
        if (step < 2)
            return false ;

        tempi = e*di ;
        if (tempi%deltan == 1)
        {
            d = di ;
            step = 3 ;
            return true ;
        }
        else
            return false ;
    } 
 
    public int getModNum ()
    { return n ; }
 
    public int getPubKey ()
    { 
        if (step < 3)
            return 0 ;
        else
            return e ; 
    }

    public int getSecKey ()
    { 
        if (step < 3)
            return 0 ;
        else
            return d ; 
    }

    public int gcd (int a, int b)
    {
        if (b == 0)
            return a ;
        else
            return this.gcd(b, a%b) ;
    }   

    public int modExpo (int a, int b, int ni)
    {  // computer a^b%n using binary presentaiton of b
        int m, i, base, k ;

        base = 32768 ; 
       /* 2^15, we only calculate 16 bits 
          because of JOOS's lacking of bit shift opcode
       */
        k = b/base ;
         
        m = 1 ;
        for (i=0; i<=15; i++)
        {
            k = b/base ;
            m = (m*m)%ni ;
            if (k%2 == 1)
                m = (m*a)%ni ;
            base = base/2 ;
        }
        return m ;
    } 
  
    public String encryption (String src)
    {
        int i, length ;
        String rst ;
        
        if (step < 3)
            return null ;
 
        rst = new String("") ;

        for (i=0; i<src.length(); i++)
            rst = rst + (char)this.modExpo(src.charAt(i), e, n) ; 
        
        return rst ;
    }

    public String decryption (String dest)
    {
        int i, length ;
        String src ;
     
        if (step < 3)
            return null ;
    
        src = new String("") ;
    
        for (i=0; i<dest.length(); i++)
            src = src+(char)this.modExpo(dest.charAt(i), d, n) ;

        return src ;
    }
}
      
