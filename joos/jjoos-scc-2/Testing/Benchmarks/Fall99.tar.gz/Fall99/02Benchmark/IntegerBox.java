import joos.lib.*;
import java.util.*;

public class IntegerBox{
  protected int val;
  protected boolean valueSet;
  protected JoosIO f;


  public IntegerBox(){
    super();
    valueSet = false;
    val = 0;
    f = new JoosIO();
  }

  public int get(){
    while( valueSet == false)
      new JoosThread(null).sleep(100);
    f.println("Reader read : " + val);
    valueSet = false;
    return val;
  }

  public void put(int i){
    while( valueSet == true)
      new JoosThread(null).sleep(300);
    val = i;
    f.println("Writer write: " + i);
    valueSet = true;
  }
}
