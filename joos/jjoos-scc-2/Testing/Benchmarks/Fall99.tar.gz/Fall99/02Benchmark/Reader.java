import joos.lib.*;

public class Reader extends Thread{
  protected IntegerBox box;
  protected int counter;
  
  public Reader(IntegerBox b, int i){
    super((Thread) null);
    box = b;
    counter = i;
  }

  public void run(){
    int i;
    i = 0;
    while(i < counter){
      box.get( );
      i = i+1;
    }
  }
}
