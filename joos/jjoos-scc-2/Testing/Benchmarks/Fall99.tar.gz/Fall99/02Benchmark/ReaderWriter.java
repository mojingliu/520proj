import joos.lib.*;

public class ReaderWriter{

  public ReaderWriter(){
    super();
  }

  public static void main(String args[]){
    IntegerBox box;
    Reader r;
    Writer w;
    int count;
    JoosIO f;

    f = new JoosIO();
    f.println("Please enter an integer (better less than 100):");
    count = f.readInt();
    box = new IntegerBox();

    w = new Writer(box, count);
    r = new Reader(box, count);
    
    w.start();
    r.start();
  }
}
