import joos.lib.*;
import java.util.*;
public class date {
    public date() {super(); }
    public int findDay()
    {  Date D;
      D = new Date();
      return (D.getDay());}
     public int findMonth()
      { Date D;
       D = new Date();
       return (D.getMonth());}
 }
