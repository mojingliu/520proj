import joos.lib.*;
import java.util.*;
public class con{
    protected String content;
    protected int topicnum;
    protected con next;
    public con(int t, String s, con C)
    {   super();
        content=s;
        topicnum = t;
        next = C;}
    public String getcontent()
       { return content;}
    public int  gettopnum()
       { return topicnum;}
    public con getnext()
    {   return next;   }
}


