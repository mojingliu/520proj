import joos.lib.*;

public class Matrix
{
protected String name;
protected int numRows;
protected int numCols;
protected boolean isInitialized;
	
public Matrix()
    {
	super();
	name = null;
	numRows = 0;
	numCols = 0;
	isInitialized = false;
    }
	
public Matrix(String nameArg, int rows, int cols)
    {
	super();
	name = nameArg;

	if( (rows < 0) || (cols < 0) )
	{
	    isInitialized = false;
	    rows = 0;
	    cols = 0;
	}
	else
	{
	    isInitialized = true;
	}
		
	numRows = rows;
	numCols = cols;
    }
	
public boolean initialize(String name, int rows, int cols)
    {
	boolean resultOK;
		
	resultOK = false;
		
	name = name;
		
	if( (rows < 0) || (cols < 0) )
	{
	    resultOK = false;
	    return resultOK;
	}

	numRows = rows;
	numCols = cols;
	isInitialized = true;
	resultOK = true;
		
	return resultOK;
    }
	
public String getName()
    {
	return name;
    }
	
public int getNumRows()
    {
	return numRows;
    }
	
public int getNumCols()
    {
	return numCols;
    }
	
public boolean printMatrix()
    {
	JoosIO jio;
		
	jio = new JoosIO();
		
	if(!isInitialized)
	{
	    return false;
	}
		
	jio.print(name);
	jio.print("[");
	jio.print(numRows + ",");
	jio.print(numCols + "]");
	return true;		
    }
	
public String toString()
    {
	StringBuffer tmpStrBuf;
	int nameLength;
	int estSubscriptLength;
	int totalEstLength;
		
	nameLength = name.length();
	estSubscriptLength = 1 + 4 + 1 + 4 + 1;
	totalEstLength = nameLength + estSubscriptLength;
		
	if(!isInitialized)
	{
	    return null;
	}
		
	tmpStrBuf = new StringBuffer(totalEstLength);
	tmpStrBuf.append(name);
	tmpStrBuf.append("[" + numRows + "," + numCols + "]");
		
	return tmpStrBuf.toString();
    }
}
