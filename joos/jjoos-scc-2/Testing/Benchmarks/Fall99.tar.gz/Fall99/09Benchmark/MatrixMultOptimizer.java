import java.util.*;
import joos.lib.*;

public class MatrixMultOptimizer
{
protected Vector matrices;		// Vector of Matrix
protected boolean isMatrixListSet;
protected Vector solution;		// Vector of int
	
public MatrixMultOptimizer()
    {
	super();
		
	matrices = new Vector(50);
	solution = null;
	isMatrixListSet = false;
    }

public static void main(String argv[])
    {
	MatrixMultOptimizer mmo;
	JoosIO jio;
	JoosSystem js;
	int minNumMults;
	String optimalSolution;

	mmo = new MatrixMultOptimizer();
	jio = new JoosIO();
	js = new JoosSystem();

	if(!mmo.readInputData())
	{
	    jio.print("\n\nERROR: Problem reading input data, exiting.\n\n");
	    js.exit(8);
	}
	
	minNumMults = mmo.getOptimalNumMults();
	optimalSolution = mmo.getSolutionString();

	jio.print(
	    "\n\nUnder an optimal parenthesization, there would be " +
	    minNumMults +
	    " multiplications in total." +
	    "\n\nThe optimal parenthesization is:\n\t"); 
	jio.print(optimalSolution + "\n\n");
	
	return;
    }

public Vector getSolution()
    {
	return solution;
    }

public boolean setIsMatrixListSet(boolean arg)
    {
	if(matrices.size() <= 0)
	{
	    return false;
	}
	else
	{
	    isMatrixListSet = true;
	}

	return true;
    }
	
public boolean printMatrixList()
    {
	JoosIO jio;
	Matrix tmpMatrix;
	int i;

	jio = new JoosIO();
	i = 0;

	if(!isMatrixListSet)
	{
	    return false;
	}
		
	for(i=0; i<matrices.size(); i=i+1)
	{
	    tmpMatrix = (Matrix) matrices.elementAt(i);
	    tmpMatrix.printMatrix();
	    jio.print(" ");			
	}
		
	return true;
    }
	
public String matrixListAsString()
    {
	StringBuffer tmpStrBuf;
	Matrix tmpMatrix;
	int estNamesLength;
	int estSubscriptLength;
	int spacerLength;
	int estTotalLength;
	int i;

	estNamesLength = 5 * matrices.size();
	estSubscriptLength = (1 + 4 + 1 + 4 + 1) * matrices.size();
	spacerLength = matrices.size() - 1;
	estTotalLength = estNamesLength + estSubscriptLength + spacerLength;
	i = 0;
		
	tmpStrBuf = new StringBuffer(estTotalLength);
		
	if(!isMatrixListSet)
	{
	    return null;
	}
		
	for(i=0; i<matrices.size(); i=i+1)
	{
	    tmpMatrix = (Matrix) matrices.elementAt(i);
	    tmpStrBuf.append(tmpMatrix.toString());
	    tmpStrBuf.append(" ");
	}
		
	return tmpStrBuf.toString();
    }
	
public boolean validateMatrices() 
    {
	JoosIO jio;
	Matrix tmpMatrix1;
	Matrix tmpMatrix2;
	int lastMult;
	int i;

	jio = new JoosIO();				
	lastMult = matrices.size() - 1;
	i = 0;

	if(!isMatrixListSet)
	{
	    return false;
	}

	for(i=0; i<lastMult; i=i+1)
	{
	    tmpMatrix1 = (Matrix)matrices.elementAt(i);
	    tmpMatrix2 = (Matrix)matrices.elementAt(i+1);
			
	    if(tmpMatrix1.getNumCols() == tmpMatrix2.getNumRows())
	    {
	    }			
	    else
	    {
		jio.println("INPUT DATA ERROR: Matrix Size Conflict.");
		jio.println("\tAt least two of your matrices have " +
			    "incompatible sizes:");
		jio.println("\t\t" + tmpMatrix1.toString() +
			    " x " + tmpMatrix2.toString());
		jio.println("\tColumns of 1st must equal rows of 2nd, " +
			    "for matrix multiplication.");
		return false;
	    }
	}

	return true;
    }
	
public boolean readInputData()
    {
	JoosIO jio;
	JoosSystem js;
	String matrixData;
	StringBuffer matrixDataBuf;
	StringTokenizer tokenizer;
	int i;
	int tmp1;
	int tmp2;
	String tmpName;
	int tmpRows;
	int tmpCols;
	JoosString tmpJoosStr;
	String token;
		
	jio = new JoosIO();
	js = new JoosSystem();
	matrixDataBuf = new StringBuffer(1024);
	matrixData = null;
	tokenizer = null;
	i = 0;
	tmp1 = 0;
	tmp2 = 0;
	tmpName = null;
	tmpRows = -1;
	tmpCols = -1;
	tmpJoosStr = null;
	token = null;
		
	jio.print("\nEnter your list of matrices all on one line and" +
		  " in the form:\n\n\t<matrix1_name>[<rows>,<cols>] " +
		  "<matrix2_name>[<rows>,<cols>]\n\nwhere <matrix#_name> " +
		  "is the name of each matrix, and <rows> and <cols>\n" +
		  "specify its integer dimensions. Hit Enter when " +
		  "finished.\n\n");
		
	matrixData = jio.readLine();
		
	tokenizer = new StringTokenizer(matrixData, "\t ", false);
	while(tokenizer.hasMoreTokens())
	{
	    token = tokenizer.nextToken("\t ");

	    tmp1 = token.indexOf("[", 0);
	    if(tmp1 < 0)
	    {
		jio.print("\n\nERROR: improperly formated input.\n");
		jio.print("Couldn't find '[' in your matrix " +
			  "specification:\n\n\t" + token + "\n\n");
		js.exit(8);
	    }
	    tmpName = token.substring(0, tmp1);
			
	    tmp1 = token.indexOf("[", 0);
	    tmp2 = token.indexOf(",", 0);
	    if( (tmp1 < 0) || (tmp2 < 0) )
	    {
		jio.print("\n\nERROR: improperly formated input.\n");
		jio.print("Failed to either find '[' or find ',' in" +
			  " the following matrix specification:\n\n\t" +
			  token + "\n\n");
		js.exit(8);
	    }
	    tmpJoosStr = new JoosString(token.substring(tmp1+1,tmp2));
	    tmpRows = tmpJoosStr.string2Int();

	    tmp1 = token.indexOf(",", 0);
	    tmp2 = token.indexOf("]", 0);
	    if( (tmp1 < 0) || (tmp2 < 0) )
	    {
		jio.print("\n\nERROR: improperly formated input.\n");
		jio.print("Failed to either find ',' or find ']' in the" +
			  " following matrix specification:\n\n\t" +
			  token + "\n\n");
		js.exit(8);
	    }
	    tmpJoosStr = new JoosString(token.substring(tmp1+1,tmp2));
	    tmpCols = tmpJoosStr.string2Int();
			
	    matrices.addElement(new Matrix(tmpName, tmpRows, tmpCols));
	}
		
	if(!this.setIsMatrixListSet(true))
	{
	    jio.print("\n\nERROR: Reading and parsing input data" +
		      " gave inconsistent results.\n\n");
	    return false;
	}
		
	return true;
    }
	
public int getOptimalNumMults()
    {
	Vector d;		// Vector of int
	Vector m;		// Vector of int (~2D array)
	int val1;
	int val2;
	int val3;
	int val;
	int i;
	int p;
	int j;
	int k;
	JoosIO jio;
	JoosSystem js;

	d = null;
	m = new Vector(matrices.size() * matrices.size()); // n^2 sized array
	jio = new JoosIO();
	js = new JoosSystem();

	// Check that matrices can be multiplied legally:
	if(!this.validateMatrices())
	{
	    jio.print("\nExiting...\n");
	    js.exit(8);
	}

	// Allocate space for solution array
	// n^2 sized array
	solution = new Vector(matrices.size() * matrices.size());
						
	// Construct dimensions array (d0, d1, d2,...,dn) where size of
	// matrix Ai is (di-1 by di).
	d = this.getDimensionsArray();
		
	// Initialize whole table for m and this.solution so can reference each
	// cell by indeces afterwards.
	for(i=0; i<matrices.size(); i++)
	{
	    for(j=0; j<matrices.size(); j=j+1)
	    {
		m.addElement(new Integer(0));
		solution. addElement(new Integer(0));
	    }
	}
		
	// Fill in upper right triangle of m:
	// For each successive diagonal 1..(n-1) about the main diagonal...
	for(p=2; p<=matrices.size(); p=p+1)
	{
	    // Fill it in from upper to lower entries
	    for(i=1; i<=matrices.size()-p+1; i=i+1)
	    {
		j = i + p - 1;
		// Integer.MAX_VALUE ('infinity' in this case)
		m.setElementAt(new Integer(2147483647), this.idxTrans(i,j));	

		for(k=i; k<j; k=k+1)
		{
		    val1 = ((Integer)m.elementAt(
			this.idxTrans(i,k))).intValue();
		    val2 = ((Integer)m.elementAt(
			this.idxTrans(k+1, j))).intValue();
		    val3 = ((Integer)d.elementAt(i-1)).intValue() *
			((Integer)d.elementAt(k)).intValue() *
			((Integer)d.elementAt(j)).intValue();
		    if( (val1 == 2147483647)|| (val2 == 2147483647))
		    {
			val = 2147483647;
		    }
		    else
		    {
			val = val1 + val2 + val3;
		    }
					    
		    if(((Integer)m.elementAt(
			this.idxTrans(i,j))).intValue() > val)
		    {
			m.setElementAt(new Integer(val), this.idxTrans(i,j));
			solution.setElementAt(new Integer(k),
					      this.idxTrans(i,j));
		    }
		}
	    }
	}
		
	// DEBUG: print m and s, for curiosity and confirmation

	jio.print("\nLOOK-UP TABLE:");
	for(i=0; i<matrices.size();i++)
	{
	    jio.print("\n\t");
	    for(j=0; j<matrices.size();j++)
	    {
		jio.print(m.elementAt(this.idxTrans(i+1,j+1)) + " ");
	    }
	}

	jio.print("\n\nBACKTRACKING TABLE:");
	for(i=0; i<matrices.size();i++)
	{
	    jio.print("\n\t");
	    for(j=0; j<matrices.size();j++)
	    {
		jio.print(solution.elementAt(this.idxTrans(i+1,j+1)) + " ");
	    }
	}

	return ((Integer)m.elementAt(
	    this.idxTrans(1, matrices.size()))).intValue();
    }
	
public Vector getDimensionsArray()
    {
	Vector d;
	Matrix tmpMatrix;
	int i;
		
	d = new Vector(matrices.size()+1);
	tmpMatrix = null;
	i = 0;
		
	// For the ith matrix Ai in the matrix list, it has dimensions
	// di-1 x di for i=1,2...n. Thus, create the n+1 element array
	// d = [d0,d1,d2,...,dn].
		
	if(!isMatrixListSet)
	{
	    return null;
	}
		
	// Fill in d[0] from 1st matrix
	tmpMatrix = (Matrix)matrices.elementAt(0);
	d.addElement(new Integer(tmpMatrix.getNumRows()));
		
	// Iterate over rest of matrices to fill in d[1]-d[n-1]
	for(i=1; i<matrices.size(); i=i+1)
	{
	    tmpMatrix = (Matrix)matrices.elementAt(i);
	    d.addElement(new Integer(tmpMatrix.getNumRows()));
	}
		
	// Fill in d[n] from last matrix. Note that i = n at this point;
	// last matrix is at i - 1
	tmpMatrix = (Matrix)matrices.elementAt(i - 1);
	d.addElement(new Integer(tmpMatrix.getNumCols()));
		
	return d;
    }
	
public String getSolutionString()
    {
	if(!isMatrixListSet)
	{
	    return null;
	}
	
	return this.getSolutionStr(1, matrices.size());
    }

public String getSolutionStr(int startIdx, int endIdx)
    {
	StringBuffer answerBuf;
	int estNamesLength;
	int estSubscriptLength;
	int estSpacerLength;
	int estTotalLength;
	Matrix tmpMatrix;

	tmpMatrix = null;
	estNamesLength = 5 * matrices.size();
	estSubscriptLength = (1 + 4 + 1 + 4 + 1) * matrices.size();
	estSpacerLength = 2*matrices.size();
	estTotalLength = estNamesLength + estSubscriptLength + estSpacerLength;
	answerBuf = new StringBuffer(estTotalLength);

	// Note: startIdx and endIdx are for a 1-based table. This is because
	// the conversion method idxTrans() (used elsewhere) assumes indeces
	// for a 1-based table are being provided.
    
	if( (startIdx < 1) || (endIdx > matrices.size()) || (!isMatrixListSet))
	{
	    return null;
	}

	if(endIdx > startIdx)
	{
	    answerBuf.append("( ");
	    answerBuf.append(
		this.getSolutionStr(
		    startIdx,
		    ((Integer)solution.elementAt(
			this.idxTrans(startIdx,endIdx))).intValue()));
	    answerBuf.append(
		this.getSolutionStr(
		    ((Integer)solution.elementAt(
			this.idxTrans(startIdx,endIdx))).intValue()+1,endIdx));
	    answerBuf.append(") ");
	}
	else
	{
	    tmpMatrix = (Matrix)matrices.elementAt(startIdx-1);
	    answerBuf.append(tmpMatrix.getName());
	    answerBuf.append(" ");
	}
		
	return answerBuf.toString();
    }
	
public int idxTrans(int row, int col)
    {
	return (matrices.size()*(row-1) + (col-1));
    }
}
